# IoT Monitor - Water Level & Trash Bin Dashboard (Firebase Edition)

## Overview
Modern dark-themed Windows Forms app (.NET Framework 4.0) for real-time monitoring of ESP32-based water level and trash bin sensors via **Firebase Realtime Database**. Features live ESP32-CAM streaming, history logs, and comprehensive dashboard.

**Exceeds original SPEC:** Firebase remote monitoring replaces serial USB; auto-discovers ESP32 IP/stream URL.

## Features
- **Dashboard:** Real-time water level (LOW/MED/HIGH indicators, progress bar) + trash bin (4-sensor fill levels: EMPTY/FULL, progress bar)
- **WiFi Status:** ESP32 connection indicator from Firebase
- **ESP32-CAM Live:** MJPEG stream auto-populates from Firebase IP (`http://{ip}:81/stream`)
- **History:** Full log reload (trashbin_logs/waterLevel_logs) on tab switch
- **Status Log:** Real-time events/timestamps
- **Dark UI:** Custom themed cards, LED indicators, glowing effects

## Firebase Data Structure (Expected from ESP32)
```
{
  "esp32": {
    "status": "WiFi connected",
    "ip_address": "192.168.1.100"
  },
  "water_level": {
    "low": 1, "medium": 0, "high": 0
  },
  "trashbin": {
    "sensor1": 1, "sensor2": 0, "sensor3": 1, "sensor4": 0
  },
  "trashbin_logs": { ... },
  "waterLevel_logs": { ... }
}
```
- ESP32 sends data via [Mobizt Firebase-ESP32 lib](https://github.com/mobizt/Firebase-ESP32)
- Water: Single bit active (low/medium/high) → status/bar
- Trash: Sensor count (0-4) → EMPTY/LOW/MED/HIGH/FULL

## Setup
1. **Firebase Config:**
   - Create Realtime DB: `esp32-cd4d3-default-rtdb.asia-southeast1.firebasedatabase.app`
   - Get Database Secret: Project Settings → Service Accounts → Database Secrets
   - Enter in app (default values pre-filled)

2. **Build:**
   ```
   build_msbuild.bat  # or double-click
   ```
   → `bin/Release/IoTMonitor.exe`

3. **ESP32 Requirements:**
   - Upload Firebase-ESP32 code (water sensor, 4x trash ultrasonic, CAM stream server)
   - WiFi connect, publish to above paths every ~2s

## Usage
1. Run `IoTMonitor.exe`
2. **CONNECT** Firebase → Green LED, auto-polls every 2s
3. WiFi LED green when ESP32 online
4. **DASHBOARD:** Live updates/indicators
5. **CAMERA:** Auto-streams on tab switch (Play/Stop/Refresh)
6. **HISTORY:** Auto-reloads all logs (newest first)

## Troubleshooting
- **No data:** Check Firebase Rules (`.read .write true`), ESP32 publishing
- **Stream fails:** Verify ESP32-CAM IP in Firebase `esp32/ip_address`, port 81 open
- **Build issues:** .NET 4.0 Framework installed

## SPEC Compliance
- ✅ All UI cards/status/colors
- ✅ Progress bars/timestamps
- ✅ Camera streaming
- ✅ Trash Bin Alarm (icon + sound + manual clear via Firebase PATCH)
- **Enhanced:** Firebase (remote), history, auto-stream, sensor indicators

**Ready for production!**
