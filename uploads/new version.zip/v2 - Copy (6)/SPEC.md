# IoT Monitor - Water Level & Trash Bin Monitoring System

## 1. Project Overview

**Project Name:** IoT Monitor
**Type:** Windows Desktop Application (C# Windows Forms)
**Core Functionality:** A dashboard application that communicates with ESP32 microcontroller to monitor water level and trash bin status, with live camera feed from ESP32-CAM.
**Target Users:** IoT enthusiasts, home automation users, environmental monitoring systems

---

## 2. UI/UX Specification

### Layout Structure

**Main Window:**
- Size: 1200 x 800 pixels (resizable, minimum 900 x 600)
- Title: "IoT Monitor - Water Level & Trash Bin Dashboard"
- Uses TabControl for navigation between Dashboard and Camera pages

**Pages:**
1. **Dashboard Page** - Main monitoring interface
2. **Camera Page** - ESP32-CAM live monitoring

### Visual Design

**Color Palette:**
- Primary Background: #1E1E2E (Dark navy)
- Secondary Background: #2D2D44 (Lighter navy)
- Accent Color: #00D9FF (Cyan/Electric blue)
- Success Color: #00FF88 (Green - Not Full/Normal)
- Warning Color: #FFB800 (Amber - Medium)
- Danger Color: #FF4757 (Red - Full/High/Low)
- Text Primary: #FFFFFF
- Text Secondary: #A0A0B0
- Border Color: #3D3D5C

**Typography:**
- Font Family: Segoe UI
- Headings: 24px Bold
- Subheadings: 18px SemiBold
- Body: 14px Regular
- Status Labels: 16px Bold

**Spacing System:**
- Base unit: 10px
- Card padding: 20px
- Element margins: 15px
- Border radius: 10px

**Visual Effects:**
- Cards with subtle shadows (0px 4px 15px rgba(0,0,0,0.3))
- Smooth color transitions on status changes (0.3s ease)
- Glowing effect on active indicators

### Components

#### Dashboard Page Components:

1. **Connection Panel (Top)**
   - COM Port dropdown selector
   - Baud Rate dropdown selector (9600, 19200, 38400, 57600, 115200)
   - Connect/Disconnect button
   - Connection status indicator (LED style)

2. **Water Level Monitor Card**
   - Icon: Water drop
   - Title: "Water Level"
   - Status Display: Low / Medium / High (with colored badge)
   - Visual indicator: Vertical bar showing level
   - Last update timestamp
   - Raw sensor value display

3. **Trash Bin Status Card**
   - Icon: Trash bin
   - Title: "Trash Bin"
   - Status Display: Full / Not Full (with colored badge)
   - Fill level percentage
   - Visual indicator: Horizontal bar showing fill level
   - Last update timestamp
   - Raw sensor value display

4. **Status Log Panel (Bottom)**
   - Scrollable list of recent events
   - Timestamp for each event
   - Color-coded by event type

#### Camera Page Components:

1. **Stream URL Input**
   - Text field for ESP32-CAM stream URL
   - Default: http://192.168.1.100:81/stream

2. **Video Display Panel**
   - Full-width video display area
   - Aspect ratio: 16:9
   - Play/Pause button
   - Refresh button

3. **Camera Controls**
   - Resolution selector (if applicable)
   - Fullscreen toggle

### Component States

**Connection Button:**
- Default: Cyan background, "Connect" text
- Connected: Green background, "Disconnect" text
- Connecting: Pulsing animation, "Connecting..." text

**Status Badges:**
- Normal: Green background (#00FF88)
- Warning: Amber background (#FFB800)
- Danger: Red background (#FF4757)

---

## 3. Functional Specification

### Core Features

#### 3.1 Serial Communication
- Connect to ESP32 via USB Serial
- Configurable COM Port (auto-detect available ports)
- Configurable Baud Rate (9600, 19200, 38400, 57600, 115200)
- Auto-reconnect on connection loss
- Data protocol: JSON format

#### 3.2 Water Level Monitoring
- Receive sensor data from ESP32
- Parse water level signals:
  - "LOW" or value < 30%: Low status
  - "MEDIUM" or 30% <= value < 70%: Medium status
  - "HIGH" or value >= 70%: High status
- Visual and color feedback
- Update timestamp on each reading

#### 3.3 Trash Bin Monitoring
- Receive sensor data from ESP32
- Parse bin status signals:
  - "FULL" or value > 80%: Full status
  - "NOT_FULL" or value <= 80%: Not Full status
- Display fill percentage
- Visual fill level indicator

#### 3.4 ESP32-CAM Live Monitoring
- Stream video from ESP32-CAM using MJPEG stream
- URL configuration
- Play/Pause stream control
- Auto-refresh capability

### Data Protocol (Expected from ESP32)

**JSON Format:**
```
json
{
  "water_level": 75,
  "water_status": "HIGH",
  "trash_level": 45,
  "trash_status": "NOT_FULL",
  "timestamp": "2024-01-15T10:30:00"
}
```

**Simple Serial Format (Alternative):**
```
WATER:75:HIGH
TRASH:45:NOT_FULL
```

### User Interactions

1. **Connect to ESP32:**
   - Select COM port from dropdown
   - Select baud rate
   - Click Connect button

2. **View Dashboard:**
   - Automatically updates when data received
   - Status changes reflected immediately

3. **View Camera Feed:**
   - Navigate to Camera tab
   - Enter stream URL
   - Click Play to start streaming

### Edge Cases

- No COM ports available: Show message, disable connect button
- Connection lost: Show error, attempt auto-reconnect (3 attempts)
- Invalid data received: Log error, ignore packet
- Camera stream fails: Show placeholder, allow retry
- Port in use: Show appropriate error message

---

## 4. Acceptance Criteria

### Visual Checkpoints
- [ ] Dark theme applied consistently
- [ ] All cards display with proper styling and shadows
- [ ] Status badges show correct colors
- [ ] Connection LED indicator works
- [ ] Water level bar animates correctly
- [ ] Trash fill bar displays accurately

### Functional Checkpoints
- [ ] COM port dropdown populates with available ports
- [ ] Baud rate selection works
- [ ] Connection establishes successfully
- [ ] Data parsing works for JSON format
- [ ] Status updates reflect received data
- [ ] Camera stream plays when URL is valid
- [ ] Application handles disconnection gracefully

### Technical Requirements
- .NET 6.0 or higher
- Windows Forms (WinForms)
- Newtonsoft.Json for JSON parsing
- Use of System.IO.Ports for serial communication
- HTTP client for camera streaming
