using System;
using System.Drawing;
using System.Net;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Timers;
using System.Media;
using System.Collections.Generic;
using System.Text.RegularExpressions;


namespace IoTMonitor
{
    public partial class MainForm : Form
    {
        // Colors - Modern dark theme
        private Color primaryBg = Color.FromArgb(20, 20, 35);
        private Color secondaryBg = Color.FromArgb(30, 30, 50);
        private Color cardBg = Color.FromArgb(40, 40, 65);
        private Color accentColor = Color.FromArgb(0, 200, 255);
        private Color accentDark = Color.FromArgb(0, 150, 200);
        private Color successColor = Color.FromArgb(50, 220, 120);
        private Color warningColor = Color.FromArgb(255, 180, 50);
        private Color dangerColor = Color.FromArgb(255, 80, 100);
        private Color textPrimary = Color.White;
        private Color textSecondary = Color.FromArgb(180, 180, 200);
        private Color borderColor = Color.FromArgb(80, 80, 120);

        // Firebase Components
        private TextBox txtFirebaseUrl;
        private TextBox txtFirebaseSecret;
        private Button btnFirebaseConnect;
        private PictureBox firebaseLedIndicator;
        private bool isFirebaseConnected = false;
        private System.Timers.Timer firebaseTimer;
        
        // WiFi Status Components (from Firebase)
        private PictureBox wifiLedIndicator;
        private Label lblWifiStatus;
        
// Water Level Components
        private Label lblWaterLevelStatus;
        private Label lblWaterValue;
        private Panel waterLevelBar;
        private Panel waterBarBg;  // Background panel for dynamic width calculation
        private Label lblWaterTimestamp;
        private Label lblWaterTotalCount;
        
        // Water Level Notify Components (NEW)
        private Label lblWaterLastStatus;
        private string waterBeforeStatus = "";
        
        // Trash Bin Components
        private Label lblTrashStatus;
        private Label lblTrashValue;
        private Panel trashLevelBar;
        private Panel trashBarBg;  // Background panel for dynamic width calculation
        private Label lblTrashTimestamp;
        private Label lblTrashTotalCount;
        
// Trash Bin Sensor Indicators
        private PictureBox sensor1Icon;
        private PictureBox sensor2Icon;
        private PictureBox sensor3Icon;
        private PictureBox sensor4Icon;
        private Label lblSensor1;
        private Label lblSensor2;
        private Label lblSensor3;
        private Label lblSensor4;

        // Alarm Components (NEW)
        private PictureBox alarmIcon;
        private bool isAlarmActive = false;
        private bool alarmBlinking = false;
        private System.Timers.Timer alarmBlinkTimer;
        private System.Timers.Timer alarmSoundTimer;
        private System.Media.SoundPlayer alarmSound;
        
        // Water Level Indicators
        private PictureBox waterLowIcon;
        private PictureBox waterMediumIcon;
        private PictureBox waterHighIcon;
        private Label lblWaterLow;
        private Label lblWaterMedium;
        private Label lblWaterHigh;
        
        // Log Components
        private ListBox lstLog;
        
        // Camera Components
        private TextBox txtStreamUrl;
        private Button btnPlayStream;
        private Button btnStopStream;
        private PictureBox picCamera;
        private Thread streamThread;
        private bool isStreaming = false;
        
// Auto Stream URL
        private bool autoStreamEnabled = true;
        private bool isIpAddressReceived = false;

// History Components
        private DataGridView dgvTrashHistory;
        private DataGridView dgvWaterHistory;
        private TabPage historyTab;
        private int lastTrashLogCount = 0;
        private int lastWaterLogCount = 0;
        private System.Timers.Timer historyTimer;
        private bool pendingHistoryReload = false;
        private string lastJsonResponse = "";

        // Layout
        private TableLayoutPanel mainLayout;
        private TableLayoutPanel dashboardLayout;

        // Firebase configuration
        private string firebaseUrl = "esp32-cd4d3-default-rtdb.asia-southeast1.firebasedatabase.app"; //without https:// and rules read and write set to true
        private string firebaseSecret = "AIzaSyDD0GBVax58BHMaiQKhbDv2IysFikQ8xLg"; //Setting > Gernal > Web API Key (Create Web > Register App > Web API Key)
        

public MainForm()
        {
            try
            {
                this.Icon = new Icon("IoTIcon.ico");
            }
            catch (Exception iconEx)
            {
                // Icon missing OK, use default
                System.Diagnostics.Debug.WriteLine("Icon load failed: " + iconEx.Message);
            }
            InitializeComponent();
            SetupUI();
            LogMessage("Application started - Firebase Only Mode", "INFO");
        }

        private void InitializeComponent()
        {
            this.Text = "IoT Monitor - Water Level & Trash Bin Dashboard";
            this.Size = new Size(1400, 900);
            this.MinimumSize = new Size(1100, 750);
            this.BackColor = primaryBg;
            this.WindowState = FormWindowState.Maximized;
            this.MaximizeBox = true;
            this.MinimizeBox = true;
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.FormClosing += MainForm_FormClosing;
            this.Resize += MainForm_Resize;
            
        }

private void MainForm_Resize(object sender, EventArgs e)
        {
            if (mainLayout != null)
            {
                mainLayout.PerformLayout();
            }
            // Dynamic splitter adjustment on resize - splitHistory is local to SetupUI, so comment for reference
        }

        private void SplitHistory_SplitterMoved(object sender, SplitterEventArgs e)
        {
            // Optional: Additional logic if needed
        }

        private void SetupUI()
        {
            // Main TableLayoutPanel
            mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 3,
                ColumnCount = 1,
                BackColor = primaryBg,
                Padding = new Padding(15)
            };
            
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 50));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            this.Controls.Add(mainLayout);

            // ========== Title Panel ==========
            Panel titlePanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = primaryBg,
                Padding = new Padding(15, 10, 15, 5)
            };

            // Title
            Label lblTitle = new Label
            {
                Text = "Water Level AND Trash Bin Monitoring",
                Location = new Point(50, 5),
                Size = new Size(800, 35),
                ForeColor = accentColor,
                Font = new Font("Segoe UI", 18, FontStyle.Bold)
            };
            titlePanel.Controls.Add(lblTitle);

            // WiFi Status LED Indicator (from ESP32 via Firebase)
            wifiLedIndicator = new PictureBox
            {
                Location = new Point(15, 10),
                Size = new Size(22, 22),
                BackColor = Color.Gray,
                SizeMode = PictureBoxSizeMode.StretchImage
            };
            DrawWifiLedIndicator(Color.Gray);
            titlePanel.Controls.Add(wifiLedIndicator);

            // WiFi Status Label
            lblWifiStatus = new Label
            {
                Location = new Point(848, 12),
                Size = new Size(250, 22),
                Text = "Waiting for Connection...",
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 11),
                Visible = false
            };

            
            titlePanel.Controls.Add(lblWifiStatus);

            mainLayout.Controls.Add(titlePanel, 0, 0);

            // ========== Firebase Connection Panel ==========
            Panel connectionPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = secondaryBg,
                Padding = new Padding(15, 8, 15, 8)
            };

            // Firebase URL Label
            Label lblFirebaseUrl = new Label
            {
                Location = new Point(15, 12),
                Size = new Size(80, 25),
                Text = "Firebase:",
                ForeColor = textPrimary,
                Font = new Font("Segoe UI", 11, FontStyle.Bold)
            };
            connectionPanel.Controls.Add(lblFirebaseUrl);

            // Firebase URL TextBox
            txtFirebaseUrl = new TextBox
            {
                Location = new Point(100, 10),
                Size = new Size(320, 28),
                BackColor = cardBg,
                ForeColor = textPrimary,
                Font = new Font("Segoe UI", 10),
                Text =  firebaseUrl //"Firebase URL (without https://)"
            };
            connectionPanel.Controls.Add(txtFirebaseUrl);

            // Firebase Secret Label
            Label lblFirebaseSecret = new Label
            {
                Location = new Point(435, 12),
                Size = new Size(40, 25),
                Text = "Key:",
                ForeColor = textPrimary,
                Font = new Font("Segoe UI", 11, FontStyle.Bold)
            };
            connectionPanel.Controls.Add(lblFirebaseSecret);

            // Firebase Secret TextBox
            txtFirebaseSecret = new TextBox
            {
                Location = new Point(480, 10),
                Size = new Size(280, 28),
                BackColor = cardBg,
                ForeColor = textPrimary,
                Font = new Font("Segoe UI", 10),
                UseSystemPasswordChar = true,
                Text = firebaseSecret //"AIzaSyDD0GBVax58BHMaiQKhbDv2IysFikQ8xLg"
            };
            connectionPanel.Controls.Add(txtFirebaseSecret);

            // Firebase Connect Button
            btnFirebaseConnect = new Button
            {
                Location = new Point(775, 8),
                Size = new Size(140, 36),
                BackColor = warningColor,
                ForeColor = Color.Black,
                Text = "CONNECT",
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnFirebaseConnect.FlatAppearance.BorderSize = 0;
            btnFirebaseConnect.Click += BtnFirebaseConnect_Click;
            connectionPanel.Controls.Add(btnFirebaseConnect);

            // Firebase LED Indicator
            firebaseLedIndicator = new PictureBox
            {
                Location = new Point(930, 12),
                Size = new Size(26, 26),
                BackColor = Color.Gray,
                SizeMode = PictureBoxSizeMode.StretchImage
            };
            DrawFirebaseLedIndicator(Color.Gray);
            connectionPanel.Controls.Add(firebaseLedIndicator);

            // Firebase Status Label
            Label lblFirebaseStatus = new Label
            {
                Location = new Point(965, 14),
                Size = new Size(150, 25),
                Text = "Firebase",
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 11)
            };
            connectionPanel.Controls.Add(lblFirebaseStatus);

            mainLayout.Controls.Add(connectionPanel, 0, 1);

            // ========== TabControl ==========
            TabControl tabControl = new TabControl
            {
                Dock = DockStyle.Fill,
                BackColor = primaryBg,
                ForeColor = textPrimary,
                Padding = new Point(70, 6),
                ItemSize = new Size(180, 45)
            };
            tabControl.SelectedIndexChanged += TabControl_SelectedIndexChanged;

            // Dashboard Tab
            TabPage dashboardTab = new TabPage("  DASHBOARD  ");
            dashboardTab.BackColor = primaryBg;
            dashboardTab.Padding = new Padding(15);
            
            
            // Camera Tab
            TabPage cameraTab = new TabPage("  ESP32-CAM LIVE  ");
            cameraTab.BackColor = primaryBg;
            cameraTab.Padding = new Padding(15);

            // History Tab
            historyTab = new TabPage("  HISTORY  ");
            historyTab.BackColor = primaryBg;
            historyTab.Padding = new Padding(15);

            tabControl.TabPages.Add(dashboardTab);
            tabControl.TabPages.Add(cameraTab);
            tabControl.TabPages.Add(historyTab);
            mainLayout.Controls.Add(tabControl, 0, 2);

            // ========== Dashboard Content ==========
            dashboardLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 3,
                ColumnCount = 2,
                BackColor = primaryBg,
                Padding = new Padding(5)
            };
            
            dashboardLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
            dashboardLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
            dashboardLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            dashboardLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            dashboardTab.Controls.Add(dashboardLayout);

            // Water Level Card
            Panel waterCard = CreateCard("WATER LEVEL MONITOR");
            dashboardLayout.Controls.Add(waterCard, 0, 0);

            // NEW: Water Notify Label (top-right, aligned w/ title)
            lblWaterLastStatus = new Label
            {
                Text = "Last Status: --",
                Location = new Point(300, 15),
                Size = new Size(300, 25),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleRight
            };
            waterCard.Controls.Add(lblWaterLastStatus);
            waterCard.Controls.SetChildIndex(lblWaterLastStatus, 0);  // Top layer

            // Water content
            lblWaterLevelStatus = new Label
            {
                Text = "WAITING FOR DATA...",
                Location = new Point(20, 60),
                Size = new Size(400, 45),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 22, FontStyle.Bold)
            };
            waterCard.Controls.Add(lblWaterLevelStatus);

            waterBarBg = new Panel
            {
                Location = new Point(20, 120),
                Size = new Size(500, 38),
                BackColor = Color.FromArgb(60, 60, 90)
            };
            waterCard.Controls.Add(waterBarBg);

            waterLevelBar = new Panel
            {
                Location = new Point(20, 120),
                Size = new Size(0, 38),
                BackColor = accentColor
            };
            // Add progress bar BEFORE background panel so it appears on top
            waterCard.Controls.Add(waterLevelBar);
            waterCard.Controls.SetChildIndex(waterLevelBar, 0);

            lblWaterValue = new Label
            {
                Text = "0%",
                Location = new Point(530, 120),
                Size = new Size(80, 38),
                ForeColor = textPrimary,
                Font = new Font("Segoe UI", 20, FontStyle.Bold)
            };
            waterCard.Controls.Add(lblWaterValue);

            lblWaterTimestamp = new Label
            {
                Text = "Last update: ---",
                Location = new Point(20, 170),
                Size = new Size(350, 30),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 11)
            };
            waterCard.Controls.Add(lblWaterTimestamp);

            lblWaterTotalCount = new Label
            {
                Text = "Water Level Change Total Count : --",
                Location = new Point(20, 195),
                Size = new Size(250, 22),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 11)
            };
            waterCard.Controls.Add(lblWaterTotalCount);

            // Water Level Indicators (LOW, MEDIUM, HIGH)
            Label lblWaterIndicators = new Label
            {
                Text = "Level Indicators:",
                Location = new Point(20, 225),
                Size = new Size(120, 22),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 11)
            };
            waterCard.Controls.Add(lblWaterIndicators);

            // LOW indicator
            waterLowIcon = new PictureBox
            {
                Location = new Point(150, 220),
                Size = new Size(28, 28),
                BackColor = Color.Gray,
                SizeMode = PictureBoxSizeMode.StretchImage
            };
            DrawIndicatorIcon(waterLowIcon, Color.Gray);
            waterCard.Controls.Add(waterLowIcon);

            lblWaterLow = new Label
            {
                Text = "LOW",
                Location = new Point(182, 223),
                Size = new Size(50, 22),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            waterCard.Controls.Add(lblWaterLow);

            // MEDIUM indicator
            waterMediumIcon = new PictureBox
            {
                Location = new Point(250, 220),
                Size = new Size(28, 28),
                BackColor = Color.Gray,
                SizeMode = PictureBoxSizeMode.StretchImage
            };
            DrawIndicatorIcon(waterMediumIcon, Color.Gray);
            waterCard.Controls.Add(waterMediumIcon);

            lblWaterMedium = new Label
            {
                Text = "MED",
                Location = new Point(282, 223),
                Size = new Size(50, 22),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            waterCard.Controls.Add(lblWaterMedium);

            // HIGH indicator
            waterHighIcon = new PictureBox
            {
                Location = new Point(350, 220),
                Size = new Size(28, 28),
                BackColor = Color.Gray,
                SizeMode = PictureBoxSizeMode.StretchImage
            };
            DrawIndicatorIcon(waterHighIcon, Color.Gray);
            waterCard.Controls.Add(waterHighIcon);

            lblWaterHigh = new Label
            {
                Text = "HIGH",
                Location = new Point(382, 223),
                Size = new Size(50, 22),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            waterCard.Controls.Add(lblWaterHigh);

            // Trash Bin Card
            Panel trashCard = CreateCard("TRASH BIN MONITOR");
            dashboardLayout.Controls.Add(trashCard, 1, 0);

            // NEW: Alarm Icon Button (top-right)
            alarmIcon = new PictureBox
            {
                Location = new Point(500, 20),
                Size = new Size(30, 30),
                BackColor = Color.Transparent,
                SizeMode = PictureBoxSizeMode.StretchImage,
                Cursor = Cursors.Hand,
                Visible = false
            };
            alarmIcon.Click += AlarmIcon_Click;
            DrawAlarmIcon(false);
            trashCard.Controls.Add(alarmIcon);
            trashCard.Controls.SetChildIndex(alarmIcon, 0);  // Top layer

            lblTrashStatus = new Label
            {
                Text = "WAITING FOR DATA...",
                Location = new Point(20, 60),
                Size = new Size(400, 45),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 22, FontStyle.Bold)
            };
            trashCard.Controls.Add(lblTrashStatus);

            trashBarBg = new Panel
            {
                Location = new Point(20, 120),
                Size = new Size(500, 38),
                BackColor = Color.FromArgb(60, 60, 90)
            };
            trashCard.Controls.Add(trashBarBg);

            trashLevelBar = new Panel
            {
                Location = new Point(20, 120),
                Size = new Size(0, 38),
                BackColor = successColor
            };
            // Add progress bar BEFORE background panel so it appears on top
            trashCard.Controls.Add(trashLevelBar);
            trashCard.Controls.SetChildIndex(trashLevelBar, 0);

            lblTrashValue = new Label
            {
                Text = "0%",
                Location = new Point(530, 120),
                Size = new Size(80, 38),
                ForeColor = textPrimary,
                Font = new Font("Segoe UI", 20, FontStyle.Bold)
            };
            trashCard.Controls.Add(lblTrashValue);

            lblTrashTimestamp = new Label
            {
                Text = "Last update: ---",
                Location = new Point(20, 170),
                Size = new Size(350, 22),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 11)
            };
            trashCard.Controls.Add(lblTrashTimestamp);

            lblTrashTotalCount = new Label
            {
                Text = "TrashBin Full Total Count : --",
                Location = new Point(20, 195),
                Size = new Size(250, 22),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 11)
            };
            trashCard.Controls.Add(lblTrashTotalCount);

            // Trash Bin Sensor Indicators (SENSOR 1-4)
            Label lblSensorIndicators = new Label
            {
                Text = "Sensor Indicators:",
                Location = new Point(20, 225),
                Size = new Size(130, 22),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 11)
            };
            trashCard.Controls.Add(lblSensorIndicators);

            // Sensor 1 indicator
            sensor1Icon = new PictureBox
            {
                Location = new Point(160, 220),
                Size = new Size(28, 28),
                BackColor = Color.Gray,
                SizeMode = PictureBoxSizeMode.StretchImage
            };
            DrawIndicatorIcon(sensor1Icon, Color.Gray);
            trashCard.Controls.Add(sensor1Icon);

            lblSensor1 = new Label
            {
                Text = "S1",
                Location = new Point(192, 223),
                Size = new Size(30, 22),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            trashCard.Controls.Add(lblSensor1);

            // Sensor 2 indicator
            sensor2Icon = new PictureBox
            {
                Location = new Point(240, 220),
                Size = new Size(28, 28),
                BackColor = Color.Gray,
                SizeMode = PictureBoxSizeMode.StretchImage
            };
            DrawIndicatorIcon(sensor2Icon, Color.Gray);
            trashCard.Controls.Add(sensor2Icon);

            lblSensor2 = new Label
            {
                Text = "S2",
                Location = new Point(272, 223),
                Size = new Size(30, 22),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            trashCard.Controls.Add(lblSensor2);

            // Sensor 3 indicator
            sensor3Icon = new PictureBox
            {
                Location = new Point(320, 220),
                Size = new Size(28, 28),
                BackColor = Color.Gray,
                SizeMode = PictureBoxSizeMode.StretchImage
            };
            DrawIndicatorIcon(sensor3Icon, Color.Gray);
            trashCard.Controls.Add(sensor3Icon);

            lblSensor3 = new Label
            {
                Text = "S3",
                Location = new Point(352, 223),
                Size = new Size(30, 22),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            trashCard.Controls.Add(lblSensor3);

            // Sensor 4 indicator
            sensor4Icon = new PictureBox
            {
                Location = new Point(400, 220),
                Size = new Size(28, 28),
                BackColor = Color.Gray,
                SizeMode = PictureBoxSizeMode.StretchImage
            };
            DrawIndicatorIcon(sensor4Icon, Color.Gray);
            trashCard.Controls.Add(sensor4Icon);

            lblSensor4 = new Label
            {
                Text = "S4",
                Location = new Point(432, 223),
                Size = new Size(30, 22),
                ForeColor = textSecondary,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            trashCard.Controls.Add(lblSensor4);

            // Log Card - spans both columns
            Panel logCard = CreateCard("STATUS LOG");
            dashboardLayout.SetColumn(logCard, 0);
            dashboardLayout.SetRow(logCard, 1);
            dashboardLayout.SetColumnSpan(logCard, 2);
            dashboardLayout.Controls.Add(logCard, 0, 1);

            lstLog = new ListBox
            {
                Location = new Point(15, 50),
                Size = new Size(1280, 200),
                BackColor = Color.FromArgb(25, 25, 45),
                ForeColor = textPrimary,
                Font = new Font("Consolas", 12),
                BorderStyle = BorderStyle.None,
                IntegralHeight = false
            };
            logCard.Controls.Add(lstLog);

            // ========== Camera Tab Content ==========
            
            // Controls
            Panel camControls = new Panel
            {
                Location = new Point(10, 10),
                Size = new Size(1300, 45),
                BackColor = Color.Transparent
            };

            Label lblStreamUrl = new Label
            {
                Location = new Point(10, 10),
                Size = new Size(110, 28),
                Text = "Stream URL:",
                ForeColor = textPrimary,
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };
            camControls.Controls.Add(lblStreamUrl);

            txtStreamUrl = new TextBox
            {
                Location = new Point(130, 8),
                Size = new Size(650, 30),
                BackColor = cardBg,
                ForeColor = textPrimary,
                Font = new Font("Segoe UI", 11),
                Text = "http://192.168.1.100:81/stream"
            };
            camControls.Controls.Add(txtStreamUrl);

            btnPlayStream = new Button
            {
                Location = new Point(800, 5),
                Size = new Size(100, 35),
                BackColor = successColor,
                ForeColor = Color.Black,
                Text = "PLAY",
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnPlayStream.FlatAppearance.BorderSize = 0;
            btnPlayStream.Click += BtnPlayStream_Click;
            camControls.Controls.Add(btnPlayStream);

            btnStopStream = new Button
            {
                Location = new Point(910, 5),
                Size = new Size(100, 35),
                BackColor = dangerColor,
                ForeColor = Color.White,
                Text = "STOP",
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnStopStream.FlatAppearance.BorderSize = 0;
            btnStopStream.Click += BtnStopStream_Click;
            camControls.Controls.Add(btnStopStream);

            Button btnRefreshCam = new Button
            {
                Location = new Point(1020, 5),
                Size = new Size(110, 35),
                BackColor = accentColor,
                ForeColor = Color.Black,
                Text = "REFRESH",
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnRefreshCam.FlatAppearance.BorderSize = 0;
            btnRefreshCam.Click += (s, e) => { StopStream(); StartStream(); };
            camControls.Controls.Add(btnRefreshCam);

            cameraTab.Controls.Add(camControls);

            // Camera PictureBox
            picCamera = new PictureBox
            {
                Location = new Point(25, 80),
                Size = new Size(1320, 500),
                BackColor = Color.Black,
                SizeMode = PictureBoxSizeMode.Zoom,
                BorderStyle = BorderStyle.FixedSingle
            };
            cameraTab.Controls.Add(picCamera);

            // History Tab Content
SplitContainer splitHistory = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                SplitterDistance = 500,
                BackColor = primaryBg
            };
            splitHistory.SplitterMoved += SplitHistory_SplitterMoved;
            splitHistory.SplitterWidth = 5;
            splitHistory.SplitterDistance = splitHistory.Width / 2;

            // Trash History Panel
TableLayoutPanel trashHistoryLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1,
                BackColor = primaryBg,
                Padding = new Padding(15)
            };
trashHistoryLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 35)); // Optimized title height
            trashHistoryLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            Label lblTrashTitle = new Label
            {
                Text = "TRASHBIN HISTORY",
                Dock = DockStyle.Fill,
                ForeColor = textPrimary,
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Margin = new Padding(0, 0, 0, 5)
            };
            trashHistoryLayout.Controls.Add(lblTrashTitle, 0, 0);

int idWidth = 80;
            int dateWidth = 180;
            int timeWidth = 140;
            int statusWidth = 300; // Auto-adjust remaining space

            dgvTrashHistory = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.Black,
                ForeColor = Color.White,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font("Consolas", 11),
                BorderStyle = BorderStyle.FixedSingle,
                GridColor = accentColor,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing,
                ColumnHeadersHeight = 32,
                RowTemplate = { Height = 30 },
                DefaultCellStyle = { Padding = new Padding(4, 2, 4, 2) },
                AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
            };
            dgvTrashHistory.ColumnHeadersDefaultCellStyle.BackColor = accentColor;
            dgvTrashHistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgvTrashHistory.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            dgvTrashHistory.RowsDefaultCellStyle.BackColor = Color.Black;
            dgvTrashHistory.AlternatingRowsDefaultCellStyle.BackColor = Color.Black;
            dgvTrashHistory.EnableHeadersVisualStyles = false;
            dgvTrashHistory.ColumnHeadersDefaultCellStyle.BackColor = accentColor;
            dgvTrashHistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgvTrashHistory.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            dgvTrashHistory.RowsDefaultCellStyle.BackColor = Color.Black;
            dgvTrashHistory.AlternatingRowsDefaultCellStyle.BackColor = Color.Black;
            dgvTrashHistory.Columns.Add("ID", "ID");
            dgvTrashHistory.Columns.Add("Date", "Date");
            dgvTrashHistory.Columns.Add("Time", "Time");
            dgvTrashHistory.Columns.Add("Status", "Status");
            dgvTrashHistory.Columns["ID"].Width = idWidth;
            dgvTrashHistory.Columns["Date"].Width = dateWidth;
            dgvTrashHistory.Columns["Time"].Width = timeWidth;
            dgvTrashHistory.Columns["Status"].Width = statusWidth;
            dgvTrashHistory.EnableHeadersVisualStyles = false;
            trashHistoryLayout.Controls.Add(dgvTrashHistory, 0, 1);

            splitHistory.Panel1.Controls.Add(trashHistoryLayout);

            // Water History Panel
TableLayoutPanel waterHistoryLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1,
                BackColor = primaryBg,
                Padding = new Padding(15)
            };
waterHistoryLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 35)); // Optimized title height
            waterHistoryLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

Label lblWaterTitle = new Label
            {
                Text = "WATER LEVEL HISTORY",
                Dock = DockStyle.Fill,
                ForeColor = textPrimary,
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Margin = new Padding(0, 0, 0, 5)
            };
            waterHistoryLayout.Controls.Add(lblWaterTitle, 0, 0);

            dgvWaterHistory = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.Black,
                ForeColor = Color.White,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font("Consolas", 11),
                BorderStyle = BorderStyle.FixedSingle,
                GridColor = accentColor,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing,
                ColumnHeadersHeight = 32,
                RowTemplate = { Height = 30 },
                DefaultCellStyle = { Padding = new Padding(4, 2, 4, 2) },
                AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
            };
            dgvWaterHistory.ColumnHeadersDefaultCellStyle.BackColor = accentColor;
            dgvWaterHistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgvWaterHistory.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            dgvWaterHistory.RowsDefaultCellStyle.BackColor = Color.Black;
            dgvWaterHistory.AlternatingRowsDefaultCellStyle.BackColor = Color.Black;
            dgvWaterHistory.EnableHeadersVisualStyles = false;
            dgvWaterHistory.ColumnHeadersDefaultCellStyle.BackColor = accentColor;
            dgvWaterHistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgvWaterHistory.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            dgvWaterHistory.RowsDefaultCellStyle.BackColor = Color.Black;
            dgvWaterHistory.AlternatingRowsDefaultCellStyle.BackColor = Color.Black;
            dgvWaterHistory.Columns.Add("ID", "ID");
            dgvWaterHistory.Columns.Add("Date", "Date");
            dgvWaterHistory.Columns.Add("Time", "Time");
            dgvWaterHistory.Columns.Add("Status", "Status");
            dgvWaterHistory.Columns["ID"].Width = idWidth;
            dgvWaterHistory.Columns["Date"].Width = dateWidth;
            dgvWaterHistory.Columns["Time"].Width = timeWidth;
            dgvWaterHistory.Columns["Status"].Width = statusWidth;
            dgvWaterHistory.EnableHeadersVisualStyles = false;
            waterHistoryLayout.Controls.Add(dgvWaterHistory, 0, 1);

            splitHistory.Panel2.Controls.Add(waterHistoryLayout);

            historyTab.Controls.Add(splitHistory);

            StyleTabControl(tabControl);
        }

        private Panel CreateCard(string title)
        {
            Panel card = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = cardBg,
                Margin = new Padding(8),
                Padding = new Padding(15)
            };

            Label lblTitle = new Label
            {
                Text = title,
                Location = new Point(15, 12),
                Size = new Size(600, 30),
                ForeColor = textPrimary,
                Font = new Font("Segoe UI", 16, FontStyle.Bold)
            };
            card.Controls.Add(lblTitle);

            card.Paint += (s, e) =>
            {
                using (Pen p = new Pen(borderColor, 2))
                {
                    e.Graphics.DrawRectangle(p, 1, 1, card.Width - 2, card.Height - 2);
                }
            };

            return card;
        }

        private void StyleTabControl(TabControl tc)
        {
            tc.DrawMode = TabDrawMode.OwnerDrawFixed;
            tc.DrawItem += (s, e) =>
            {
                Rectangle r = tc.GetTabRect(e.Index);
                Brush bgBrush = new SolidBrush(secondaryBg);
                e.Graphics.FillRectangle(bgBrush, r);
                
                Brush textBrush = new SolidBrush(textPrimary);
                StringFormat sf = new StringFormat
                {
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center
                };
                
                if (tc.SelectedIndex == e.Index)
                {
                    using (Brush highlight = new SolidBrush(accentColor))
                    {
                        e.Graphics.FillRectangle(highlight, r.X, r.Bottom - 3, r.Width, 3);
                    }
                    textBrush = new SolidBrush(accentColor);
                }
                
                e.Graphics.DrawString(tc.TabPages[e.Index].Text, 
                    new Font("Segoe UI", 13, FontStyle.Bold), textBrush, r, sf);
                
                bgBrush.Dispose();
                textBrush.Dispose();
            };
        }

        private void DrawFirebaseLedIndicator(Color color)
        {
            Bitmap bmp = new Bitmap(20, 20);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                
                if (color != Color.Gray)
                {
                    using (Brush glow = new SolidBrush(Color.FromArgb(80, color)))
                    {
                        g.FillEllipse(glow, 0, 0, 20, 20);
                    }
                }
                
                using (Brush br = new SolidBrush(color))
                {
                    g.FillEllipse(br, 3, 3, 14, 14);
                }
            }
            firebaseLedIndicator.Image = bmp;
        }

        private void DrawWifiLedIndicator(Color color)
        {
            Bitmap bmp = new Bitmap(20, 20);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                
                if (color != Color.Gray)
                {
                    using (Brush glow = new SolidBrush(Color.FromArgb(80, color)))
                    {
                        g.FillEllipse(glow, 0, 0, 20, 20);
                    }
                }
                
                using (Brush br = new SolidBrush(color))
                {
                    g.FillEllipse(br, 3, 3, 14, 14);
                }
            }
            wifiLedIndicator.Image = bmp;
        }

        private void DrawIndicatorIcon(PictureBox pb, Color color)
        {
            Bitmap bmp = new Bitmap(24, 24);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                
                if (color != Color.Gray)
                {
                    // Draw outer circle (filled)
                    using (Brush br = new SolidBrush(color))
                    {
                        g.FillEllipse(br, 2, 2, 20, 20);
                    }
                    
                    // Draw inner highlight
                    using (Brush highlight = new SolidBrush(Color.FromArgb(100, Color.White)))
                    {
                        g.FillEllipse(highlight, 5, 5, 8, 8);
                    }
                }
                else
                {
                    // Gray (inactive) - draw hollow circle
                    using (Pen p = new Pen(Color.Gray, 2))
                    {
                        g.DrawEllipse(p, 3, 3, 18, 18);
                    }
                }
            }
            pb.Image = bmp;
        }

        // Firebase Connection
        private void BtnFirebaseConnect_Click(object sender, EventArgs e)
        {
            if (isFirebaseConnected)
            {
                DisconnectFirebase();
            }
            else
            {
                ConnectFirebase();
            }
        }

        private void ConnectFirebase()
        {
            firebaseUrl = txtFirebaseUrl.Text.Trim();
            firebaseSecret = txtFirebaseSecret.Text.Trim();

            if (string.IsNullOrEmpty(firebaseUrl) || firebaseUrl.Contains("YOUR-PROJECT"))
            {
                MessageBox.Show("Please enter a valid Firebase URL", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrEmpty(firebaseSecret) || firebaseSecret.Contains("YOUR-"))
            {
                MessageBox.Show("Please enter a valid Firebase Secret Key", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                isFirebaseConnected = true;
                
                btnFirebaseConnect.Text = "DISCONNECT";
                btnFirebaseConnect.BackColor = dangerColor;
                DrawFirebaseLedIndicator(successColor);
                UpdateWifiStatus(true, "Connected");
                txtFirebaseUrl.Enabled = false;
                txtFirebaseSecret.Enabled = false;
                
                // Start timer to read from Firebase every 2 seconds
                firebaseTimer = new System.Timers.Timer(2000);
                firebaseTimer.Elapsed += OnFirebaseTimerElapsed;
                firebaseTimer.Start();
                
                LogMessage(string.Format("🔄 Firebase reconnected: {0} - Fresh read initiated", firebaseUrl), "FIREBASE");
                LogMessage("Reading data from Firebase every 2 seconds", "FIREBASE");
                
                // Force full history reload flag for reconnect
                pendingHistoryReload = true;
                
                ReadFromFirebase();
            }
            catch (Exception ex)
            {
                isFirebaseConnected = false;
                UpdateWifiStatus(false, "Disconnected");
                MessageBox.Show(string.Format("Firebase connection failed: {0}", ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                LogMessage(string.Format("Firebase error: {0}", ex.Message), "ERROR");
            }
        }

        private void OnFirebaseTimerElapsed(object sender, ElapsedEventArgs e)
        {
            if (isFirebaseConnected)
            {
                this.Invoke(new Action(() => ReadFromFirebase()));
            }
        }

        private void ReadFromFirebase()
        {
            bool retry = false;
            try
            {
                string url = "https://" + firebaseUrl + "/.json?auth=" + firebaseSecret;
                
                using (WebClient client = new WebClient())
                {
                    string jsonResponse = client.DownloadString(url);
                    ParseFirebaseData(jsonResponse);
                }
            }
            catch (Exception ex)
            {
                LogMessage(string.Format("Firebase read error: {0}", ex.Message), "ERROR");
                retry = true;
            }
            
            // Retry once on failure
            if (retry && isFirebaseConnected)
            {
                Thread.Sleep(1000);  // 1s delay
                try
                {
                    string url = "https://" + firebaseUrl + "/.json?auth=" + firebaseSecret;
                    using (WebClient client = new WebClient())
                    {
                        string jsonResponse = client.DownloadString(url);
                        ParseFirebaseData(jsonResponse);
                        LogMessage("Firebase read retry successful", "FIREBASE");
                    }
                }
                catch (Exception ex2)
                {
                    LogMessage(string.Format("Firebase retry failed: {0}", ex2.Message), "ERROR");
                }
            }
        }

        private int GetLogCount(string json, string logPath)
        {
            int logStart = json.IndexOf("\"" + logPath + "\":");
            if (logStart < 0) return 0;

            // Find log section
            int objStart = json.IndexOf("{", logStart);
            if (objStart < 0) return 0;
            int objEnd = -1;
            int braceCount = 1;
            for (int i = objStart + 1; i < json.Length; i++)
            {
                if (json[i] == '{') braceCount++;
                else if (json[i] == '}') braceCount--;
                if (braceCount == 0) { objEnd = i; break; }
            }
            if (objEnd < 0) return 0;

            string logSection = json.Substring(objStart, objEnd - objStart + 1);

            // Count valid entries
            int currentCount = 0;
            int pos = 0;
            while (pos < logSection.Length)
            {
                int keyStart = logSection.IndexOf("\"", pos);
                if (keyStart < 0) break;
                int keyEnd = logSection.IndexOf("\"", keyStart + 1);
                if (keyEnd < 0) break;
                int entryStart = logSection.IndexOf("{", keyEnd);
                if (entryStart < 0) { pos = keyEnd + 1; continue; }
                int entryEnd = FindMatchingBrace(logSection, entryStart);
                if (entryEnd > entryStart) currentCount++;
                pos = entryStart + 1;
            }

            return currentCount;
        }

        private void ParseFirebaseData(string json)
        {
            lastJsonResponse = json;  // Store for full reload
            
            try
            {
                // Update log counts
                // MessageBox.Show(json);
                int trashCount = GetLogCount(json, "trashbin_logs");
                lblTrashTotalCount.Text = "TrashBin Full Total Count : " + trashCount;
                
                int waterCount = GetLogCount(json, "waterLevel_logs");
                lblWaterTotalCount.Text = "Water Level Change Total Count: " + waterCount;

                // Parse logs - trashbin_logs FIRST for trash history
                ParseLogs(json, "trashbin_logs", dgvTrashHistory, ref lastTrashLogCount, true);
                
                // Parse logs - waterLevel_logs SECOND for water history
                ParseLogs(json, "waterLevel_logs", dgvWaterHistory, ref lastWaterLogCount, true);
                
                // Parse the JSON structure from Mobizt Firebase Client:
                // {
                //   "esp32": {
                //     "status": "WiFi connected",
                //     "ip_address": "192.168.1.100"
                //   },
                //   "trashbin": { "empty": 1, "full": 0 },
                //   "water_level": { "high": 1, "low": 0, "medium": 0 }
                // }
                
                // Find ESP32 status section
                int esp32Start = json.IndexOf("\"esp32\":");
                if (esp32Start >= 0)
                {
                    int espObjStart = json.IndexOf("{", esp32Start);
                    int espObjEnd = json.IndexOf("}", espObjStart);
                    if (espObjStart >= 0 && espObjEnd >= 0)
                    {
                        string espSection = json.Substring(espObjStart, espObjEnd - espObjStart + 1);
                        
                        // Parse IP address field (for stream URL)
                        int ipStart = espSection.IndexOf("\"ip_address\":");
                        if (ipStart >= 0)
                        {
                            int colonPos = espSection.IndexOf(":", ipStart);
                            if (colonPos >= 0)
                            {
                                int endPos = espSection.IndexOfAny(new char[] {',', '}'}, colonPos);
                                string ipValue = espSection.Substring(colonPos + 1, endPos - colonPos - 1).Trim();
                                // Remove quotes
                                ipValue = ipValue.Trim('"');
                                
                                if (!string.IsNullOrEmpty(ipValue) && ipValue.Contains("."))
                                {
                                    // Auto-update stream URL from Firebase
                                    HandleIpAddressFromFirebase(ipValue);
                                }
                            }
                        }
                        
                        // Parse status field
                        int statusStart = espSection.IndexOf("\"status\":");
                        if (statusStart >= 0)
                        {
                            int colonPos = espSection.IndexOf(":", statusStart);
                            if (colonPos >= 0)
                            {
                                int endPos = espSection.IndexOfAny(new char[] {',', '}'}, colonPos);
                                string statusValue = espSection.Substring(colonPos + 1, endPos - colonPos - 1).Trim();
                                // Remove quotes
                                statusValue = statusValue.Trim('"');
                                
                                // Update WiFi status based on status value
                                if (statusValue.Contains("connected") || statusValue.Contains("Connected"))
                                {
                                    UpdateWifiStatus(true, "Connected");
                                }
                                else if (statusValue.Contains("connecting") || statusValue.Contains("Connecting"))
                                {
                                    UpdateWifiStatus(false, "Connecting...");
                                }
                                else
                                {
                                    UpdateWifiStatus(false, "" + statusValue);
                                }
                            }
                        }
                    }
                }
                
                // Find water_level section
                int waterStart = json.IndexOf("\"water_level\":");
                if (waterStart >= 0)
                {
                    int waterObjStart = json.IndexOf("{", waterStart);
                    int waterObjEnd = json.IndexOf("}", waterObjStart);
                    if (waterObjStart >= 0 && waterObjEnd >= 0)
                    {
                        string waterSection = json.Substring(waterObjStart, waterObjEnd - waterObjStart + 1);
                        
                        int low = GetJsonValue(waterSection, "low");
                        int medium = GetJsonValue(waterSection, "medium");
                        int high = GetJsonValue(waterSection, "high");
                        
                        string status = "LOW";
                        int level = 0;
                        
                        if (high == 1) { status = "HIGH"; level = 100; }
                        else if (medium == 1) { status = "MEDIUM"; level = 50; }
                        else if (low == 1) { status = "LOW"; level = 25; }
                        else { status = "EMPTY"; level = 0; }
                        
                        UpdateWaterLevelFromFirebase(level, status);
                        UpdateWaterLevelIndicators(low, medium, high);
                    }
                }
                
                // Find trashbin section
                int trashStart = json.IndexOf("\"trashbin\":");
                if (trashStart >= 0)
                {
                    int trashObjStart = json.IndexOf("{", trashStart);
                    int trashObjEnd = json.IndexOf("}", trashObjStart);
                    if (trashObjStart >= 0 && trashObjEnd >= 0)
                    {
                        string trashSection = json.Substring(trashObjStart, trashObjEnd - trashObjStart + 1);
                        
                        // Parse sensor values (sensor1, sensor2, sensor3, sensor4)
                        int sensor1 = GetJsonValue(trashSection, "sensor1");
                        int sensor2 = GetJsonValue(trashSection, "sensor2");
                        int sensor3 = GetJsonValue(trashSection, "sensor3");
                        int sensor4 = GetJsonValue(trashSection, "sensor4");
                        
                        // Calculate status based on number of sensors triggered
                        int sensorCount = sensor1 + sensor2 + sensor3 + sensor4;
                        
                        string status;
                        int level;
                        
                        // Determine status based on sensor count
                        switch (sensorCount)
                        {
                            case 0:
                                status = "EMPTY";
                                level = 0;
                                break;
                            case 1:
                                status = "LOW";
                                level = 25;
                                break;
                            case 2:
                                status = "MEDIUM";
                                level = 50;
                                break;
                            case 3:
                                status = "HIGH";
                                level = 75;
                                break;
                            case 4:
                                status = "FULL";
                                level = 100;
                                break;
                            default:
                                status = "UNKNOWN";
                                level = 0;
                                break;
                        }
                        
                        UpdateTrashFromFirebase(level, status);
                        UpdateTrashSensorIndicators(sensor1, sensor2, sensor3, sensor4);

                        // NEW: Parse trashbin_notify/statusFull for alarm
                        int notifyStart = json.IndexOf("\"trashbin_notify\":");
                        if (notifyStart >= 0)
                        {
                            int notifyObjStart = json.IndexOf("{", notifyStart);
                            int notifyObjEnd = json.IndexOf("}", notifyObjStart);
                            if (notifyObjStart >= 0 && notifyObjEnd >= 0)
                            {
                                string notifySection = json.Substring(notifyObjStart, notifyObjEnd - notifyObjStart + 1);
                                int statusFull = GetJsonValue(notifySection, "statusFull");
                                UpdateAlarm(statusFull == 1);
                            }
                        }

                        // NEW: Parse waterLevel_notify (like trashbin_notify)
                        notifyStart = json.IndexOf("\"waterLevel_notify\":");
                        if (notifyStart >= 0)
                        {
                            int notifyObjStart = json.IndexOf("{", notifyStart);
                            int notifyObjEnd = json.IndexOf("}", notifyObjStart);
                            if (notifyObjStart >= 0 && notifyObjEnd >= 0)
                            {
                                string notifySection = json.Substring(notifyObjStart, notifyObjEnd - notifyObjStart + 1);
                                // Assume {statusChange:1, beforeStatus:"LOW", currentStatus:"HIGH"}
                                string beforeStatus = ExtractJsonString(notifySection, "beforeStatus");
                                string currentStatus = ExtractJsonString(notifySection, "currentStatus");
                                Color statusColor = textSecondary;
                                if (beforeStatus.ToUpper().Contains("HIGH"))
                                    statusColor = dangerColor;
                                else if (beforeStatus.ToUpper().Contains("MEDIUM"))
                                    statusColor = warningColor;
                                else if (beforeStatus.ToUpper().Contains("LOW"))
                                    statusColor = successColor;
                                    
                                    if (this.InvokeRequired)
                                    {
                                        this.Invoke(new Action(() => {
                                            lblWaterLastStatus.Text = string.Format("Last Status: {0}", beforeStatus, currentStatus);
                                            lblWaterLastStatus.ForeColor = statusColor;
                                        }));

                                    }
                                    else
                                    {
                                        lblWaterLastStatus.Text = string.Format("Last Status: {0}" , beforeStatus);
                                        lblWaterLastStatus.ForeColor = statusColor;
                                    }
                                waterBeforeStatus = currentStatus;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogMessage(string.Format("Parse error: {0}", ex.Message), "ERROR");
            }
        }

        // NEW Alarm Methods
        private void UpdateAlarm(bool active)
        {
            if (active != isAlarmActive)
            {
                isAlarmActive = active;
                this.Invoke(new Action(() =>
                {
                    if (active && isFirebaseConnected)
                    {
                        StartAlarm();
                    }
                    else
                    {
                        StopAlarm();
                    }
                }));
                LogMessage(active ? "🚨 TRASH ALARM ACTIVE (statusFull=1) - BLINKING + CONTINUOUS SOUND" : "✅ Trash alarm cleared", "ALARM");
            }
        }

        private void DrawAlarmIcon(bool colored)
        {
            Bitmap bmp = new Bitmap(30, 30);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                Color iconColor = colored ? dangerColor : Color.Gray;
                if (colored)
                {
                    // Glow effect
                    using (Brush glow = new SolidBrush(Color.FromArgb(100, dangerColor)))
                    {
                        g.FillEllipse(glow, 0, 0, 30, 30);
                    }
                }
                // Draw bell shape
                using (Brush br = new SolidBrush(iconColor))
                {
                    // Bell body
                    g.FillEllipse(br, 8, 12, 14, 14);
                    // Bell top
                    g.FillRectangle(br, 12, 5, 6, 8);
                    // Bell clapper
                    g.FillEllipse(br, 14, 18, 2, 3);
                }
            }
            alarmIcon.Image = bmp;
        }

        private void StartAlarm()
        {
            alarmBlinking = true;
            alarmVisibleState = true;
            alarmIcon.Visible = true;

            // Blink timer - 500ms toggle
            if (alarmBlinkTimer == null)
            {
                alarmBlinkTimer = new System.Timers.Timer(700);
                alarmBlinkTimer.Elapsed += OnAlarmBlinkElapsed;
            }
            alarmBlinkTimer.Start();

            // Sound timer - loop every 1000ms (1s)
            if (alarmSoundTimer == null)
            {
                alarmSoundTimer = new System.Timers.Timer(1300);
                alarmSoundTimer.Elapsed += OnAlarmSoundElapsed;
            }
            alarmSoundTimer.Start();


            LogMessage("🚨 EMERGENCY ALARM: Blinking + MULTI-TONE started", "ALARM");
        }

        private void StopAlarm()
        {
            alarmBlinking = false;
            if (alarmBlinkTimer != null)
            {
                alarmBlinkTimer.Stop();
            }
            if (alarmSoundTimer != null)
            {
                alarmSoundTimer.Stop();
            }
            alarmIcon.Visible = false;
            alarmVisibleState = true;
            LogMessage("🔇 Emergency alarm stopped", "ALARM");
        }

        private bool alarmVisibleState = true;
        private int alarmToneIndex = 0;
        
        private void OnAlarmBlinkElapsed(object sender, ElapsedEventArgs e)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action(() => OnAlarmBlinkElapsed(sender, e)));
                return;
            }
            
            if (alarmBlinking && isAlarmActive)
            {
                alarmVisibleState = !alarmVisibleState;
                DrawAlarmIcon(alarmVisibleState);
            }
        }

        private void OnAlarmSoundElapsed(object sender, ElapsedEventArgs e)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action(() => OnAlarmSoundElapsed(sender, e)));
                return;
            }
            
            if (alarmBlinking && isFirebaseConnected)
            {
                // MAX LOUD BEEP - Console speaker bypasses mixer
                Console.Beep(800, 400);  // 1000Hz, 500ms - LOUD siren tone
            }
        }

        private void AlarmIcon_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Is the Trashbin Empty?", "Clear Alarm", 
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                StopAlarm();
                ClearAlarmOnFirebase();
            }
            // If No, alarm continues blinking
        }

        private void ClearAlarmOnFirebase()
        {
            try
            {
                // Clear alarm status first
                string patchUrl = "https://" + firebaseUrl + "/trashbin_notify.json?auth=" + firebaseSecret;
                string patchData = "{\"statusFull\":0}";
                using (WebClient wc = new WebClient())
                {
                    wc.Headers["Content-Type"] = "application/json";
                    string response = wc.UploadString(patchUrl, "PATCH", patchData);
                    LogMessage("🚨 Alarm cleared - PATCHed trashbin_notify/statusFull=0", "ALARM");
                }

                // Append to trashbin_logs with next ID
                string logsUrl = "https://" + firebaseUrl + "/trashbin_logs.json?auth=" + firebaseSecret;
                string today = DateTime.Now.ToString("MMMM dd, yyyy");
                string time = DateTime.Now.ToString("HH:mm");
                
                // Get current logs to find next ID
                using (WebClient wcLogs = new WebClient())
                {
                    string logsJson = wcLogs.DownloadString(logsUrl);
                    int nextId = 1;
                    if (!string.IsNullOrEmpty(logsJson) && logsJson != "null")
                    {
                        // Simple parsing to find max ID (assuming IDs are sequential numbers)
                        int lastIdMatch = 0;
                        var idMatches = Regex.Matches(logsJson, @"\""id(\d+)\"":", RegexOptions.IgnoreCase);
                        foreach (Match m in idMatches)
                        {
                            int idNum;
                            if (int.TryParse(m.Groups[1].Value, out idNum))
                            {
                                if (idNum > lastIdMatch) lastIdMatch = idNum;
                            }
                        }
                        nextId = lastIdMatch + 1;
                    }
                    
                    string logEntry = string.Format("{{\"id{0}\": {{\"date\": \"{1}\", \"time\": \"{2}\", \"status\": \"FULL\"}}}}", nextId, today, time);
                    wcLogs.UploadString(logsUrl, "PATCH", logEntry);
                }
LogMessage(string.Format("📝 Appended to trashbin_logs: id1 - {0} {1} FULL", today, time), "ALARM");

                UpdateAlarm(false);  // Hide immediately
            }
            catch (Exception ex)
            {
LogMessage("Failed to clear alarm and log to Firebase: " + ex.Message, "ERROR");
MessageBox.Show("Failed to update Firebase: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Full history reload on tab switch when new data detected
        private void FullReloadHistory()
        {
            if (!string.IsNullOrEmpty(lastJsonResponse) && pendingHistoryReload)
            {
                dgvTrashHistory.Rows.Clear();
                dgvWaterHistory.Rows.Clear();
                ParseLogs(lastJsonResponse, "trashbin_logs", dgvTrashHistory, ref lastTrashLogCount, false);
                ParseLogs(lastJsonResponse, "waterLevel_logs", dgvWaterHistory, ref lastWaterLogCount, false);
                pendingHistoryReload = false;
                LogMessage("HISTORY: Full reload - all logs refreshed", "HISTORY");
            }
        }

private void TabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            TabControl tc = (TabControl)sender;
            if (tc.SelectedIndex == 1)
            {
                if (isFirebaseConnected && !isStreaming && !string.IsNullOrEmpty(txtStreamUrl.Text) && 
                    !txtStreamUrl.Text.Contains("192.168.1.100"))
                {
                    LogMessage("Auto-starting stream on camera tab...", "CAMERA");
                    StartStream();
                }
            }
            else if (tc.SelectedIndex == 2)
            {
                FullReloadHistory();  // Reload all if pending
                if (isFirebaseConnected) ReadFromFirebase();
                // DEBUG: Log row counts on History tab select
LogMessage(string.Format("DEBUG History Tab: Trash rows={0}, Water rows={1}", dgvTrashHistory.Rows.Count, dgvWaterHistory.Rows.Count), "HISTORY");
            }
            else if (isStreaming)
            {
                StopStream();
                LogMessage("Stream stopped - left camera tab", "CAMERA");
            }
        }

        private void ParseLogs(string json, string logPath, DataGridView dgvHistory, ref int lastCount, bool checkForNew = false)
        {
            int logStart = json.IndexOf("\"" + logPath + "\":");
            if (logStart < 0) return;

            // Count entries first
            int currentCount = 0;
            int objStart = json.IndexOf("{", logStart);
            if (objStart < 0) return;
            int objEnd = -1;
            int braceCount = 1;
            for (int i = objStart + 1; i < json.Length; i++)
            {
                if (json[i] == '{') braceCount++;
                else if (json[i] == '}') braceCount--;
                if (braceCount == 0) { objEnd = i; break; }
            }
            if (objEnd < 0) return;

            string logSection = json.Substring(objStart, objEnd - objStart + 1);
            LogMessage(string.Format("{0} section: {1} chars", logPath, logSection.Length), "DEBUG");

            // Count valid entries
            int pos = 0;
            while (pos < logSection.Length)
            {
                int keyStart = logSection.IndexOf("\"", pos);
                if (keyStart < 0) break;
                int keyEnd = logSection.IndexOf("\"", keyStart + 1);
                if (keyEnd < 0) break;
                int entryStart = logSection.IndexOf("{", keyEnd);
                if (entryStart < 0) { pos = keyEnd + 1; continue; }
                int entryEnd = FindMatchingBrace(logSection, entryStart);
                if (entryEnd > entryStart) currentCount++;
                pos = entryStart + 1;
            }

            LogMessage(string.Format("{0}: Found {1} entries (prev {2})", logPath, currentCount, lastCount), "HISTORY");

            if (checkForNew && currentCount > lastCount)
            {
                pendingHistoryReload = true;
                LogMessage(string.Format("{0}: NEW entries ({1}). Full reload flagged.", logPath, currentCount-lastCount), "HISTORY");
            }

            bool doFullReload = dgvHistory.Rows.Count == 0 || pendingHistoryReload;

            if (doFullReload || currentCount > lastCount)
            {
                List<DataGridViewRow> allRows = new List<DataGridViewRow>();
                // Parse ALL entries from beginning
                pos = 0;
                int parsed = 0;
                while (pos < logSection.Length)
                {
                    int keyStart = logSection.IndexOf("\"", pos);
                    if (keyStart < 0) break;
                    int keyEnd = logSection.IndexOf("\"", keyStart + 1);
                    if (keyEnd < 0) break;
                    string idStr = logSection.Substring(keyStart + 1, keyEnd - keyStart - 1);

                    int entryStart = logSection.IndexOf("{", keyEnd);
                    if (entryStart < 0) { pos = keyEnd + 1; continue; }
                    int entryEnd = FindMatchingBrace(logSection, entryStart);
                    if (entryEnd <= entryStart) { pos = entryStart + 1; continue; }

                    string entry = logSection.Substring(entryStart, entryEnd - entryStart + 1);
                    string date = ExtractJsonString(entry, "date") ?? ExtractJsonString(entry, "data");
                    string status = ExtractJsonString(entry, "status").ToUpper();
                    string time = ExtractJsonString(entry, "time");

                    if (!string.IsNullOrEmpty(date) && !string.IsNullOrEmpty(status))
                    {
                        string matchVal = Regex.Match(idStr, @"\d+").Value; int n; int idNum = int.TryParse(matchVal, out n) ? n : parsed + 1;
                        
                        DataGridViewRow row = new DataGridViewRow();
                        row.CreateCells(dgvHistory, idNum, date.Trim('"'), time.Trim('"'), status.Trim('"'));
                        allRows.Add(row);
                        parsed++;
                    }
                    pos = entryEnd + 1;
                }
                
                dgvHistory.Rows.Clear();
                // Sort all rows by ID descending (newest first)
                allRows.Sort((r1, r2) => Convert.ToInt32(r2.Cells[0].Value).CompareTo(Convert.ToInt32(r1.Cells[0].Value)));
                // Show ALL history rows (no 10 limit)
                int rowsToAdd = allRows.Count;
                for (int i = 0; i < rowsToAdd; i++)
                {
                    dgvHistory.Rows.Add(allRows[i]);
                }
                LogMessage(string.Format("{0}: Loaded top {1}/{2} newest rows (ID desc)", logPath, rowsToAdd, parsed), "HISTORY");
                
                lastCount = currentCount;
            }
        }

        private string ExtractJsonString(string section, string key)
        {
            int keyPos = section.IndexOf("\"" + key + "\":");
            if (keyPos >= 0)
            {
                int colonPos = section.IndexOf(":", keyPos);
                if (colonPos >= 0)
                {
                    int quoteStart = section.IndexOf("\"", colonPos + 1);
                    if (quoteStart >= 0)
                    {
                        int quoteEnd = section.IndexOf("\"", quoteStart + 1);
                        if (quoteEnd > quoteStart)
                        {
                            return section.Substring(quoteStart + 1, quoteEnd - quoteStart - 1);
                        }
                    }
                }
            }
            return "";
        }
        
        private int FindMatchingBrace(string s, int startIndex)
        {
            int braceCount = 0;
            for (int i = startIndex; i < s.Length; i++)
            {
                if (s[i] == '{') braceCount++;
                else if (s[i] == '}') braceCount--;
                if (braceCount == 0) return i;
            }
            return -1;
        }

        private void UpdateWifiStatus(bool connected, string status)
        {
            if (connected)
            {
                DrawWifiLedIndicator(successColor);
                lblWifiStatus.ForeColor = successColor;
            }
            else
            {
                DrawWifiLedIndicator(dangerColor);
                lblWifiStatus.ForeColor = dangerColor;
            }
            
            lblWifiStatus.Text = status;
LogMessage(string.Format("WiFi Status: {0}", status), "FIREBASE");

            // History logs status
            if (dgvTrashHistory.Rows.Count == 0) LogMessage("Trash logs: No data in trashbin_logs", "FIREBASE");
            if (dgvWaterHistory.Rows.Count == 0) LogMessage("Water logs: No data in waterLevel_logs", "FIREBASE");
        }

        private int GetJsonValue(string section, string key)
        {
            int result = 0;
            int keyPos = section.IndexOf("\"" + key + "\"");
            if (keyPos >= 0)
            {
                int colonPos = section.IndexOf(":", keyPos);
                if (colonPos >= 0)
                {
                    int endPos = section.IndexOfAny(new char[] {',', '}'}, colonPos);
                    string value = section.Substring(colonPos + 1, endPos - colonPos - 1).Trim();
                    int.TryParse(value, out result);
                }
            }
            return result;
        }

        private void UpdateWaterLevelFromFirebase(int level, string status)
        {
            // Clamp level between 0 and 100
            level = Math.Max(0, Math.Min(100, level));
            
            lblWaterValue.Text = level + "%";
            
            // Use dynamic width based on background panel
            int maxWidth = waterBarBg != null ? waterBarBg.Width : 500;
            waterLevelBar.Width = (int)(maxWidth * level / 100.0);
            
            lblWaterLevelStatus.Text = status;
            
            Color statusColor;
            switch (status)
            {
                case "HIGH":
                    statusColor = dangerColor;
                    waterLevelBar.BackColor = dangerColor;
                    break;
                case "MEDIUM":
                    statusColor = warningColor;
                    waterLevelBar.BackColor = warningColor;
                    break;
                default:
                    statusColor = successColor;
                    waterLevelBar.BackColor = accentColor;
                    break;
            }
            
            lblWaterLevelStatus.ForeColor = statusColor;
            lblWaterTimestamp.Text = "Last update: " + DateTime.Now.ToString("HH:mm");
            LogMessage(string.Format("Firebase - Water Level: {0}% - {1}", level, status), "FIREBASE");
        }

        private void UpdateTrashFromFirebase(int level, string status)
        {
            // Clamp level between 0 and 100
            level = Math.Max(0, Math.Min(100, level));
            
            lblTrashValue.Text = level + "%";
            
            // Use dynamic width based on background panel
            int maxWidth = trashBarBg != null ? trashBarBg.Width : 500;
            trashLevelBar.Width = (int)(maxWidth * level / 100.0);
            
            lblTrashStatus.Text = status;
            
            // Change progress bar color based on status level
            Color statusColor;
            switch (status)
            {
                case "FULL":
                    statusColor = dangerColor;
                    break;
                case "HIGH":
                    statusColor = warningColor;
                    break;
                case "MEDIUM":
                    statusColor = warningColor;
                    break;
                case "LOW":
                    statusColor = successColor;
                    break;
                case "EMPTY":
                default:
                    statusColor = accentColor;
                    break;
            }
            
            trashLevelBar.BackColor = statusColor;
            lblTrashStatus.ForeColor = statusColor;
            
            lblTrashTimestamp.Text = "Last update: " + DateTime.Now.ToString("HH:mm");
            LogMessage(string.Format("Firebase - Trash Bin: {0}% - {1}", level, status), "FIREBASE");
        }

        private void UpdateWaterLevelIndicators(int low, int medium, int high)
        {
            // LOW indicator - green when active, gray when inactive
            if (low == 1)
            {
                DrawIndicatorIcon(waterLowIcon, successColor);
                lblWaterLow.ForeColor = successColor;
            }
            else
            {
                DrawIndicatorIcon(waterLowIcon, Color.Gray);
                lblWaterLow.ForeColor = textSecondary;
            }
            
            // MEDIUM indicator - yellow when active, gray when inactive
            if (medium == 1)
            {
                DrawIndicatorIcon(waterMediumIcon, warningColor);
                lblWaterMedium.ForeColor = warningColor;
            }
            else
            {
                DrawIndicatorIcon(waterMediumIcon, Color.Gray);
                lblWaterMedium.ForeColor = textSecondary;
            }
            
            // HIGH indicator - red when active, gray when inactive
            if (high == 1)
            {
                DrawIndicatorIcon(waterHighIcon, dangerColor);
                lblWaterHigh.ForeColor = dangerColor;
            }
            else
            {
                DrawIndicatorIcon(waterHighIcon, Color.Gray);
                lblWaterHigh.ForeColor = textSecondary;
            }
            
            LogMessage(string.Format("Water Indicators - Low: {0}, Medium: {1}, High: {2}", low, medium, high), "FIREBASE");
        }

        private void UpdateTrashSensorIndicators(int sensor1, int sensor2, int sensor3, int sensor4)
        {
            // Sensor 1 - green when active (detected), gray when inactive
            if (sensor1 == 1)
            {
                DrawIndicatorIcon(sensor1Icon, successColor);
                lblSensor1.ForeColor = successColor;
            }
            else
            {
                DrawIndicatorIcon(sensor1Icon, Color.Gray);
                lblSensor1.ForeColor = textSecondary;
            }
            
            // Sensor 2
            if (sensor2 == 1)
            {
                DrawIndicatorIcon(sensor2Icon, successColor);
                lblSensor2.ForeColor = successColor;
            }
            else
            {
                DrawIndicatorIcon(sensor2Icon, Color.Gray);
                lblSensor2.ForeColor = textSecondary;
            }
            
            // Sensor 3
            if (sensor3 == 1)
            {
                DrawIndicatorIcon(sensor3Icon, successColor);
                lblSensor3.ForeColor = successColor;
            }
            else
            {
                DrawIndicatorIcon(sensor3Icon, Color.Gray);
                lblSensor3.ForeColor = textSecondary;
            }
            
            // Sensor 4
            if (sensor4 == 1)
            {
                DrawIndicatorIcon(sensor4Icon, successColor);
                lblSensor4.ForeColor = successColor;
            }
            else
            {
                DrawIndicatorIcon(sensor4Icon, Color.Gray);
                lblSensor4.ForeColor = textSecondary;
            }
            
            LogMessage(string.Format("Trash Sensors - S1: {0}, S2: {1}, S3: {2}, S4: {3}", sensor1, sensor2, sensor3, sensor4), "FIREBASE");
        }

        private void DisconnectFirebase()
        {
            try
            {
                isFirebaseConnected = false;
                
                // NEW: Stop alarm
                StopAlarm();
                
                // Stop streaming when Firebase disconnects
                if (isStreaming)
                {
                    StopStream();
                    LogMessage("Stream stopped - Firebase disconnected", "CAMERA");
                }
                
                if (firebaseTimer != null)
                {
                    firebaseTimer.Stop();
                    firebaseTimer.Dispose();
                    firebaseTimer = null;
                }
                
                if (alarmBlinkTimer != null)
                {
                    alarmBlinkTimer.Stop();
                    alarmBlinkTimer.Dispose();
                    alarmBlinkTimer = null;
                }
                if (alarmSoundTimer != null)
                {
                    alarmSoundTimer.Stop();
                    alarmSoundTimer.Dispose();
                    alarmSoundTimer = null;
                }
                
                // FULL UI RESET for fresh reconnect
                lstLog.Items.Clear();  // Clear status log
                
                // Reset water UI
                lblWaterLevelStatus.Text = "WAITING FOR DATA...";
                lblWaterLevelStatus.ForeColor = textSecondary;
                waterLevelBar.Width = 0;
                waterLevelBar.BackColor = accentColor;
                lblWaterValue.Text = "0%";
                lblWaterTimestamp.Text = "Last update: ---";
                lblWaterTotalCount.Text = "Water Level Change Total Count : --";
                lblWaterLastStatus.Text = "Last Status: --";
                lblWaterLastStatus.ForeColor = textSecondary;
                waterBeforeStatus = "";
                // Reset water indicators
                DrawIndicatorIcon(waterLowIcon, Color.Gray);
                lblWaterLow.ForeColor = textSecondary;
                DrawIndicatorIcon(waterMediumIcon, Color.Gray);
                lblWaterMedium.ForeColor = textSecondary;
                DrawIndicatorIcon(waterHighIcon, Color.Gray);
                lblWaterHigh.ForeColor = textSecondary;
                
                // Reset trash UI
                lblTrashStatus.Text = "WAITING FOR DATA...";
                lblTrashStatus.ForeColor = textSecondary;
                trashLevelBar.Width = 0;
                trashLevelBar.BackColor = accentColor;
                lblTrashValue.Text = "0%";
                lblTrashTimestamp.Text = "Last update: ---";
                lblTrashTotalCount.Text = "TrashBin Full Total Count : --";
                // Reset trash sensors
                DrawIndicatorIcon(sensor1Icon, Color.Gray);
                lblSensor1.ForeColor = textSecondary;
                DrawIndicatorIcon(sensor2Icon, Color.Gray);
                lblSensor2.ForeColor = textSecondary;
                DrawIndicatorIcon(sensor3Icon, Color.Gray);
                lblSensor3.ForeColor = textSecondary;
                DrawIndicatorIcon(sensor4Icon, Color.Gray);
                lblSensor4.ForeColor = textSecondary;
                
                // Reset history
                dgvTrashHistory.Rows.Clear();
                dgvWaterHistory.Rows.Clear();
                lastTrashLogCount = 0;
                lastWaterLogCount = 0;
                pendingHistoryReload = false;
                
                // Reset WiFi & Firebase indicators
                DrawWifiLedIndicator(Color.Gray);
                lblWifiStatus.Text = "Waiting for Connection...";
                lblWifiStatus.ForeColor = textSecondary;
                DrawFirebaseLedIndicator(Color.Gray);
                
                // Reset alarms
                alarmIcon.Visible = false;
                isAlarmActive = false;
                
                btnFirebaseConnect.Text = "CONNECT";
                btnFirebaseConnect.BackColor = warningColor;
                txtFirebaseUrl.Enabled = true;
                txtFirebaseSecret.Enabled = true;
                
                LogMessage("🔄 Firebase disconnected", "FIREBASE");
            }
            catch (Exception ex)
            {
                LogMessage(string.Format("Firebase disconnect error: {0}", ex.Message), "ERROR");
            }
        }

        // Handle IP address received from Firebase
        private void HandleIpAddressFromFirebase(string ipAddress)
        {
            string streamUrl = string.Format("{0}", ipAddress); //stream Link http://{0}:81/stream
            
            // Always update the textbox with the stream URL from Firebase
            txtStreamUrl.Text = streamUrl;
            
            LogMessage(string.Format("Firebase - ESP32 IP: {0}", ipAddress), "FIREBASE");
            LogMessage(string.Format("Stream URL auto-updated: {0}", streamUrl), "CAMERA");
            
            // Auto-start stream if Firebase is connected and auto-stream is enabled
            if (isFirebaseConnected && autoStreamEnabled && !isStreaming)
            {
                LogMessage("Auto-starting stream from Firebase IP...", "CAMERA");
                StartStream();
            }
        }

        private void LogMessage(string message, string type)
        {
            string logEntry = string.Format("[{0}] [{1}] {2}", DateTime.Now.ToString("HH:mm:ss"), type, message);
            lstLog.Items.Add(logEntry);
            lstLog.TopIndex = lstLog.Items.Count - 1;
        }

        private void BtnPlayStream_Click(object sender, EventArgs e)
        {
            StartStream();
        }

        private void BtnStopStream_Click(object sender, EventArgs e)
        {
            StopStream();
        }

        private void StartStream()
        {
            if (isStreaming) return;
            
            // Check if Firebase is connected - THIS IS THE ONLY REQUIREMENT NOW
            if (!isFirebaseConnected)
            {
                LogMessage("Cannot start stream: Firebase not connected - Click FIREBASE CONNECT first", "ERROR");
                MessageBox.Show("Please connect to Firebase first to get the ESP32-CAM stream URL.", 
                    "Firebase Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            
            string url = txtStreamUrl.Text.Trim();
            if (string.IsNullOrEmpty(url) || url == "http://192.168.1.100:81/stream")
            {
                LogMessage("Cannot start stream: No valid stream URL - Wait for ESP32 IP from Firebase", "ERROR");
                MessageBox.Show("Waiting for ESP32-CAM to connect and send IP address to Firebase.Please check that ESP32-CAM is powered on and connected to WiFi.", 
                    "Waiting for ESP32-CAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            isStreaming = true;
            btnPlayStream.Enabled = false;
            btnStopStream.Enabled = true;
            streamThread = new Thread(() => StreamVideo(url));
            streamThread.IsBackground = true;
            streamThread.Start();
            LogMessage(string.Format("Starting stream: {0}", url), "CAMERA");
        }

        private void StopStream()
        {
            isStreaming = false;
            if (picCamera.Image != null)
            {
                picCamera.Image = null;
            }
            btnPlayStream.Enabled = true;
            btnStopStream.Enabled = false;
            LogMessage("Stream stopped", "CAMERA");
        }

        private void StreamVideo(string url)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.KeepAlive = true;
                request.Timeout = 15000;
                request.ReadWriteTimeout = 5000;
                
                using (WebResponse response = request.GetResponse())
                using (Stream stream = response.GetResponseStream())
                {
                    // Smaller buffer for faster processing
                    byte[] buffer = new byte[65536]; // 64KB buffer
                    byte[] frameBuffer = new byte[1024 * 512]; // 512KB for single frame
                    int framePos = 0;
                    
                    while (isStreaming && stream != null)
                    {
                        int bytesRead = stream.Read(buffer, 0, buffer.Length);
                        if (bytesRead > 0 && isStreaming)
                        {
                            // Copy to frame buffer
                            for (int i = 0; i < bytesRead && framePos < frameBuffer.Length; i++)
                            {
                                frameBuffer[framePos++] = buffer[i];
                            }
                            
                            // Try to find and display JPEG frame
                            if (framePos > 1000)
                            {
                                try
                                {
                                    // Look for JPEG start (FFD8) and end (FFD9)
                                    for (int i = 0; i < framePos - 1; i++)
                                    {
                                        if (frameBuffer[i] == 0xFF && frameBuffer[i + 1] == 0xD8)
                                        {
                                            // Find end of JPEG
                                            for (int j = i + 1; j < framePos - 1; j++)
                                            {
                                                if (frameBuffer[j] == 0xFF && frameBuffer[j + 1] == 0xD9)
                                                {
                                                    // Extract and display frame
                                                    int frameLength = j - i + 2;
                                                    if (frameLength > 100 && frameLength < frameBuffer.Length)
                                                    {
                                                        byte[] jpegData = new byte[frameLength];
                                                        Array.Copy(frameBuffer, i, jpegData, 0, frameLength);
                                                        
                                                        using (MemoryStream ms = new MemoryStream(jpegData))
                                                        {
                                                            Image img = Image.FromStream(ms);
                                                            if (isStreaming && picCamera != null && !picCamera.IsDisposed)
                                                            {
                                                                // Use Invoke for thread safety
                                                                if (picCamera.InvokeRequired)
                                                                {
                                                                    picCamera.Invoke(new Action(() => 
                                                                    {
                                                                        picCamera.Image = new Bitmap(img);
                                                                    }));
                                                                }
                                                                else
                                                                {
                                                                    picCamera.Image = new Bitmap(img);
                                                                }
                                                            }
                                                        }
                                                    }
                                                    
                                                    // Reset buffer after frame
                                                    framePos = 0;
                                                    break;
                                                }
                                            }
                                            break;
                                        }
                                    }
                                }
                                catch { }
                            }
                        }
                        // Reduced sleep for faster frame rate (10ms instead of 50ms)
                        Thread.Sleep(10);
                    }
                }
            }
            catch (Exception ex)
            {
                if (isStreaming)
                {
                    this.Invoke(new Action(() => 
                    {
                        LogMessage(string.Format("Stream error: {0}", ex.Message), "ERROR");
                    }));
                }
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            isStreaming = false;
            
            // NEW: Stop alarm
            StopAlarm();
            
            if (firebaseTimer != null)
            {
                firebaseTimer.Stop();
                firebaseTimer.Dispose();
            }
            
            if (alarmBlinkTimer != null)
            {
                alarmBlinkTimer.Stop();
                alarmBlinkTimer.Dispose();
            }
            if (alarmSoundTimer != null)
            {
                alarmSoundTimer.Stop();
                alarmSoundTimer.Dispose();
            }
            
            if (streamThread != null && streamThread.IsAlive)
            {
                streamThread.Abort();
            }
        }
    }
}

