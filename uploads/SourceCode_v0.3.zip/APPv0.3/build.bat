@echo off
 "C:\Windows\Microsoft.NET\Framework\v4.0.30319\MSBuild.exe" IoTMonitor.csproj /p:Configuration=Release
pause
