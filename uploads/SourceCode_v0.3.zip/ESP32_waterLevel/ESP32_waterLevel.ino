#include <WiFi.h>
#include <ArduinoJson.h>

#include "time.h"
const char* ntpServer = "pool.ntp.org";
const long  gmtOffset_sec = 28800;   // Philippines GMT+8
const int   daylightOffset_sec = 0;

// WIFI CHECK TIMER
unsigned long wifiCheckTime = 0;
const unsigned long wifiInterval = 60000*10; // ms

#include <FirebaseESP32.h>
#include <addons/TokenHelper.h>
#include <addons/RTDBHelper.h>
//=============================================================================================
#define API_KEY "AIzaSyDD0GBVax58BHMaiQKhbDv2IysFikQ8xLg"
#define DATABASE_URL "https://esp32-cd4d3-default-rtdb.asia-southeast1.firebasedatabase.app/"

#define USER_EMAIL "esp32cam@gmail.com"
#define USER_PASSWORD "esp32cam"

const char *ssid = "WiFi";
const char *password = "12345678";
//=============================================================================================
#define FLOAT1 25
#define FLOAT2 26
#define FLOAT3 27
bool s1,s2,s3;
String prevLevel = "UNKNOWN";
bool firstRun = true;

FirebaseData firebaseData;
FirebaseAuth auth;
FirebaseConfig Fconfig;



// Send status to Firebase 
//s1
void sendFirebaseSensor1(const int& sensor1) {
  if (Firebase.setInt(firebaseData, "/water_level/low", sensor1)) {
    Serial.println("Firebase Sensor1: " + sensor1);
  } else {
    Serial.println("Firebase Sensor1 FAILED: " + firebaseData.errorReason());
  }
}
//s2
void sendFirebaseSensor2(const int& sensor2) {
  if (Firebase.setInt(firebaseData, "/water_level/medium", sensor2)) {
    Serial.println("Firebase Sensor2: " + sensor2);
  } else {
    Serial.println("Firebase Sensor2 FAILED: " + firebaseData.errorReason());
  }
}
//s3
void sendFirebaseSensor3(const int& sensor3) {
  if (Firebase.setInt(firebaseData, "/water_level/high", sensor3)) {
    Serial.println("Firebase Sensor3: " + sensor3);
  } else {
    Serial.println("Firebase Sensor3 FAILED: " + firebaseData.errorReason());
  }
}

// Send WaterLevel initial status to Firebase
void sendFirebaseWaterLevelInitialStatus(const String& beforeStatus) {
  if (Firebase.setString(firebaseData, "/waterLevel_notify/beforeStatus", beforeStatus)) {
    Serial.println("Firebase WaterLevel Status: " + beforeStatus);
  } else {
    Serial.println("Firebase WaterLevel Status FAILED: " + firebaseData.errorReason());
  }
}

// Send WaterLevel status to Firebase
void sendFirebaseWaterLevelStatus(const String& level_status) {
  if (Firebase.setString(firebaseData, "/esp32/WaterLevel_status", level_status)) {
    Serial.println("Firebase WaterLevel Status: " + level_status);
  } else {
    Serial.println("Firebase WaterLevel Status FAILED: " + firebaseData.errorReason());
  }
}

// PRINT CURRENT TIME
void printTimeLog() {
  struct tm timeinfo;
  if(!getLocalTime(&timeinfo)){
    Serial.println("Time not available");
    return;
  }
  Serial.printf("WiFi Connected [%02d:%02d:%02d]\n",
    timeinfo.tm_hour,
    timeinfo.tm_min,
    timeinfo.tm_sec
  );
  char timeString[6];
  // HH:MM military format
  strftime(timeString,6,"%H:%M",&timeinfo);
  Serial.print("Time: ");
  Serial.println(timeString);
  String levelStatus = "WaterLevel Connected [" + String(timeString) + "]";
  sendFirebaseWaterLevelStatus(levelStatus);
}

// WIFI CHECK FUNCTION
void checkWiFi() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi lost. Reconnecting...");
    WiFi.disconnect();
    WiFi.begin(ssid, password);
    int retry = 0;
    while (WiFi.status() != WL_CONNECTED && retry < 20) {
      delay(500);
      Serial.print(".");
      retry++;
    }
    if (WiFi.status() == WL_CONNECTED) {
      Serial.println("\nReconnected!");
      printTimeLog();
    } 
    else {
      Serial.println("\nReconnect failed");
    }
  } 
  else {
    printTimeLog();
  }
}


// Water level determination: EMPTY/LOW/MEDIUM/HIGH based on sensors (active=1)
String getWaterLevel() {
  if (!s1) return "EMPTY";
  if (s1 && !s2 && !s3) return "LOW";
  if (s1 && s2 && !s3) return "MEDIUM";
  if (s1 && s2 && s3) return "HIGH";
  return "UNKNOWN";
}

// Get water status label (Low, Medium, High, Empty) from level code
String getWaterStatus() {
  String level = getWaterLevel();
  if (level == "LOW") return "Low";
  if (level == "MEDIUM") return "Medium";
  if (level == "HIGH") return "High";
  if (level == "EMPTY") return "Empty";
  return "Unknown";
}

// Get current timestamp string HH:MM
String getCurrentTimeStr() {
  struct tm timeinfo;
  if(!getLocalTime(&timeinfo)){
    return "00:00";
  }
  char timeString[6];
  strftime(timeString,6,"%H:%M",&timeinfo);
  return String(timeString);
}

// Get current date string "MMM DD, YYYY"
String getCurrentDateStr() {
  struct tm timeinfo;
  if(!getLocalTime(&timeinfo)){
    return "January 1, 1970";
  }
  char dateString[30];
  strftime(dateString,30,"%B %d, %Y",&timeinfo);
  return String(dateString);
}

// Get next log ID: stream /waterLevel_logs, find max numeric child key or 0
String getNextLogId() {
  int id = 1;
  String path;
  while (true) {
    path = "/waterLevel_logs/id" + String(id);
    if (!Firebase.getString(firebaseData, path.c_str())) {
      break;
    }
    id++;
  }
  return "id" + String(id);
}

void logWaterLevelChange(String currentLevel, String prev_level) {
  String status = getWaterStatus();
  if (status == "Unknown") return; // Skip unknown
  String nextId = getNextLogId();
  String timeStr = getCurrentTimeStr();
  String dateStr = getCurrentDateStr();
  FirebaseJson json;
  json.set("date", dateStr);
  json.set("time", timeStr);
  json.set("status", status);
  String path = "/waterLevel_logs/" + String(nextId);
  // String jsonStr;
  // json.toString(jsonStr);
  if (Firebase.setJSON(firebaseData, path, json)) {
    Serial.println("Log entry " + nextId + ": " + status + " on " + dateStr + " at " + timeStr);
  } else {
    Serial.println("Log FAILED: " + firebaseData.errorReason());
  }
}


void setup()
{
  Serial.begin(115200);
  Serial.setDebugOutput(true);
  Serial.println();

  WiFi.begin(ssid, password);
  WiFi.setSleep(false);
  Serial.print("WiFi connecting");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.println("WiFi connected");

  Fconfig.api_key = API_KEY;
  auth.user.email = USER_EMAIL;
  auth.user.password = USER_PASSWORD;
  Fconfig.database_url = DATABASE_URL;
  Fconfig.token_status_callback = tokenStatusCallback; 
  Firebase.reconnectNetwork(true);
  firebaseData.setBSSLBufferSize(4096 , 1024 );
  Firebase.begin(&Fconfig, &auth);
  Firebase.reconnectWiFi(true);
  firebaseData.setResponseSize(4096);
  // Check Firebase connection
  if (Firebase.ready())
  {
    Serial.println("Firebase Connected");
  }
  else
  {
    Serial.println("Firebase Disconnected");
  }
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  printTimeLog();

  pinMode(FLOAT1, INPUT_PULLUP);
  pinMode(FLOAT2, INPUT_PULLUP);
  pinMode(FLOAT3, INPUT_PULLUP);
}

void loop() {
  s1 = !digitalRead(FLOAT1); // active LOW = 1
  s2 = !digitalRead(FLOAT2);
  s3 = !digitalRead(FLOAT3);
  sendFirebaseSensor1(s1);
  sendFirebaseSensor2(s2);
  sendFirebaseSensor3(s3);


  if (firstRun) {
    String initialLevel = getWaterLevel();
    sendFirebaseWaterLevelInitialStatus(initialLevel);
    prevLevel = initialLevel;
    firstRun = false;
  }

  // Water level change detection and logging
  String currentLevel = getWaterLevel();
  Serial.println(currentLevel);
  if (currentLevel != prevLevel && prevLevel != "UNKNOWN") {
    logWaterLevelChange(currentLevel, prevLevel);
    sendFirebaseWaterLevelInitialStatus(prevLevel);
  }
  prevLevel = currentLevel;
  Serial.println(prevLevel);

  delay(5000);
  
  if (millis() - wifiCheckTime >= wifiInterval) {

    wifiCheckTime = millis();
    checkWiFi();
  }

}
