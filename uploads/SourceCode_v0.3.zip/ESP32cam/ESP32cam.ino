#include "esp_camera.h"
#include <WiFi.h>


#include "time.h"
const char* ntpServer = "pool.ntp.org";
const long  gmtOffset_sec = 28800;   // Philippines GMT+8
const int   daylightOffset_sec = 0;
// WIFI CHECK TIMER
unsigned long wifiCheckTime = 0;
const unsigned long wifiInterval = 60000*10; // ms

#include <FirebaseESP32.h>
#include <addons/TokenHelper.h>
#include <addons/RTDBHelper.h>
#include "board_config.h"

//========================================================================
#define API_KEY "AIzaSyDD0GBVax58BHMaiQKhbDv2IysFikQ8xLg"
#define DATABASE_URL "https://esp32-cd4d3-default-rtdb.asia-southeast1.firebasedatabase.app/"

#define USER_EMAIL "esp32cam@gmail.com"
#define USER_PASSWORD "esp32cam"

const char *ssid = "WiFi";
const char *password = "12345678";
//========================================================================

FirebaseData firebaseData;
FirebaseAuth auth;
FirebaseConfig Fconfig;

void startCameraServer();
void setupLedFlash();

// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
void sendFirebaseStatus(const String& status) {
  if (Firebase.setString(firebaseData, "/esp32/status", status)) {
    Serial.println("Firebase Status: " + status);
  } else {
    Serial.println("Firebase Status FAILED: " + firebaseData.errorReason());
  }
}
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
void sendFirebaseStream(const String& stream) {
  if (Firebase.setString(firebaseData, "/esp32/Stream", stream )) {
    Serial.println("Stream Link: http://" + stream);
  } else {
    Serial.println("Firebase Stream Link FAILED: " + firebaseData.errorReason());
  }
}
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

//StreamIpLink
void sendFirebaseIP(const String& ip) {
  if (Firebase.setString(firebaseData, "/esp32/ip_address", ip)) {
    Serial.println("Main : http://" + ip);
  } else {
    Serial.println("Firebase IP FAILED: " + firebaseData.errorReason());
  }
}

// Send Camera status to Firebase
void sendFirebaseCamStatus(const String& cam_status) {
  if (Firebase.setString(firebaseData, "/esp32/cam_status", cam_status)) {
    Serial.println("Firebase Camera Status: " + cam_status);
  } else {
    Serial.println("Firebase Camera Status FAILED: " + firebaseData.errorReason());
  }
}

// PRINT CURRENT TIME
void printTimeLog() {
  struct tm timeinfo;
  if(!getLocalTime(&timeinfo)){
    Serial.println("Time not available");
    return;
  }
  Serial.printf("WiFi Connected [%02d:%02d:%02d]\n",
    timeinfo.tm_hour,
    timeinfo.tm_min,
    timeinfo.tm_sec
  );
  char timeString[6];
  // HH:MM military format
  strftime(timeString,6,"%H:%M",&timeinfo);
  Serial.print("Time: ");
  Serial.println(timeString);
  String camStatus = "Camera Connected [" + String(timeString) + "]";
  sendFirebaseCamStatus(camStatus);
}

// WIFI CHECK FUNCTION
void checkWiFi() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi lost. Reconnecting...");
    WiFi.disconnect();
    WiFi.begin(ssid, password);
    int retry = 0;
    while (WiFi.status() != WL_CONNECTED && retry < 20) {
      delay(500);
      Serial.print(".");
      retry++;
    }
    if (WiFi.status() == WL_CONNECTED) {
      Serial.println("\nReconnected!");
      printTimeLog();
    } 
    else {
      Serial.println("\nReconnect failed");
    }
  } 
  else {
    printTimeLog();
  }
}

void setup() {
  Serial.begin(115200);
  Serial.setDebugOutput(true);
  Serial.println();
  
  WiFi.begin(ssid, password);
  WiFi.setSleep(false);

  Serial.print("WiFi connecting");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.println("WiFi connected");
  
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);

  Fconfig.api_key = API_KEY;
  auth.user.email = USER_EMAIL;
  auth.user.password = USER_PASSWORD;
  Fconfig.database_url = DATABASE_URL;
  Fconfig.token_status_callback = tokenStatusCallback; 
  Firebase.reconnectNetwork(true);
  firebaseData.setBSSLBufferSize(4096 , 1024 );
  Firebase.begin(&Fconfig, &auth);
  Firebase.reconnectWiFi(true);
  firebaseData.setResponseSize(4096);
  delay(500);
  
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.frame_size = FRAMESIZE_UXGA;
  config.pixel_format = PIXFORMAT_JPEG;  // for streaming
  //config.pixel_format = PIXFORMAT_RGB565; // for face detection/recognition
  config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
  config.fb_location = CAMERA_FB_IN_PSRAM;
  config.jpeg_quality = 12;
  config.fb_count = 1;

  if (config.pixel_format == PIXFORMAT_JPEG) {
    if (psramFound()) {
      config.jpeg_quality = 10;
      config.fb_count = 2;
      config.grab_mode = CAMERA_GRAB_LATEST;
    } else {
      // Limit the frame size when PSRAM is not available
      config.frame_size = FRAMESIZE_SVGA;
      config.fb_location = CAMERA_FB_IN_DRAM;
    }
  } else {
    // Best option for face detection/recognition
    config.frame_size = FRAMESIZE_240X240;
#if CONFIG_IDF_TARGET_ESP32S3
    config.fb_count = 2;
#endif
  }

#if defined(CAMERA_MODEL_ESP_EYE)
  pinMode(13, INPUT_PULLUP);
  pinMode(14, INPUT_PULLUP);
#endif

  // camera init
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed with error 0x%x", err);
    return;
  }

  sensor_t *s = esp_camera_sensor_get();
  // initial sensors are flipped vertically and colors are a bit saturated
  if (s->id.PID == OV3660_PID) {
    s->set_vflip(s, 1);        // flip it back
    s->set_brightness(s, 1);   // up the brightness just a bit
    s->set_saturation(s, -2);  // lower the saturation
  }
  // drop down frame size for higher initial frame rate
  if (config.pixel_format == PIXFORMAT_JPEG) {
    s->set_framesize(s, FRAMESIZE_QVGA);
  }

#if defined(CAMERA_MODEL_M5STACK_WIDE) || defined(CAMERA_MODEL_M5STACK_ESP32CAM)
  s->set_vflip(s, 1);
  s->set_hmirror(s, 1);
#endif

#if defined(CAMERA_MODEL_ESP32S3_EYE)
  s->set_vflip(s, 1);
#endif

// Setup LED FLash if LED pin is defined in camera_pins.h
#if defined(LED_GPIO_NUM)
  setupLedFlash();
#endif

  startCameraServer();
  printTimeLog();
  Serial.println("Camera Ready!");
  sendFirebaseIP("http://" + WiFi.localIP().toString() + ":81/stream");
}

void loop() {
  if (millis() - wifiCheckTime >= wifiInterval) {
    wifiCheckTime = millis();
    checkWiFi();
  }
}
