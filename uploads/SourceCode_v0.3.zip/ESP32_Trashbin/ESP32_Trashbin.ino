#include <WiFi.h>

#include "time.h"
const char* ntpServer = "pool.ntp.org";
const long  gmtOffset_sec = 28800;   // Philippines GMT+8
const int   daylightOffset_sec = 0;
// WIFI CHECK TIMER
unsigned long wifiCheckTime = 0;
const unsigned long wifiInterval = 60000 * 10; // ms

#include <FirebaseESP32.h>
#include <addons/TokenHelper.h>
#include <addons/RTDBHelper.h>

//=================================================================
#define API_KEY "AIzaSyDD0GBVax58BHMaiQKhbDv2IysFikQ8xLg"
#define DATABASE_URL "https://esp32-cd4d3-default-rtdb.asia-southeast1.firebasedatabase.app/"
#define USER_EMAIL "esp32cam@gmail.com"
#define USER_PASSWORD "esp32cam"
const char *ssid = "WiFi";
const char *password = "12345678";
//=================================================================

#define TRIG1 5
#define ECHO1 18

#define TRIG2 17
#define ECHO2 16

#define TRIG3 4
#define ECHO3 2

#define TRIG4 15
#define ECHO4 19

long duration;
float distance;
float limitDistance = 50;

FirebaseData firebaseData;
FirebaseAuth auth;
FirebaseConfig Fconfig;

int trigPins[4] = {TRIG1, TRIG2, TRIG3, TRIG4};
int echoPins[4] = {ECHO1, ECHO2, ECHO3, ECHO4};
const char* sensorPaths[4] = {"/trashbin/sensor1", "/trashbin/sensor2", "/trashbin/sensor3", "/trashbin/sensor4"};
int sensorStates[4] = {0, 0, 0, 0};




// Send status to Firebase
//s1
void sendFirebaseSensor1(const int& sensor1) {
  if (Firebase.setInt(firebaseData, "/trashbin/sensor1", sensor1)) {
    Serial.println("Firebase Sensor1: " + sensor1);
  } else {
    Serial.println("Firebase Sensor1 FAILED: " + firebaseData.errorReason());
  }
}
//s2
void sendFirebaseSensor2(const int& sensor2) {
  if (Firebase.setInt(firebaseData, "/trashbin/sensor2", sensor2)) {
    Serial.println("Firebase Sensor2: " + sensor2);
  } else {
    Serial.println("Firebase Sensor2 FAILED: " + firebaseData.errorReason());
  }
}
//s3
void sendFirebaseSensor3(const int& sensor3) {
  if (Firebase.setInt(firebaseData, "/trashbin/sensor3", sensor3)) {
    Serial.println("Firebase Sensor3: " + sensor3);
  } else {
    Serial.println("Firebase Sensor3 FAILED: " + firebaseData.errorReason());
  }
}
//s4
void sendFirebaseSensor4(const int& sensor4) {
  if (Firebase.setInt(firebaseData, "/trashbin/sensor4", sensor4)) {
    Serial.println("Firebase Sensor4: " + sensor4);
  } else {
    Serial.println("Firebase Sensor4 FAILED: " + firebaseData.errorReason());
  }
}

//full
void sendFirebaseTrashbinFull(const int& statusF) {
  if (Firebase.setInt(firebaseData, "/trashbin_notify/statusFull", statusF)) {
    Serial.println("Firebase send Full: " + statusF);
  } else {
    Serial.println("Firebase send Full FAILED: " + firebaseData.errorReason());
  }
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

float readUltrasonic(int trigPin, int echoPin)
{
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);

  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  duration = pulseIn(echoPin, HIGH);

  distance = duration * 0.034 / 2;

  return distance;
}


// Send ESPtrashbin status to Firebase
void sendFirebaseTrashbinStatus(const String& bin_status) {
  if (Firebase.setString(firebaseData, "/esp32/Trashbin_status", bin_status)) {
    Serial.println("Firebase Trashbin Status: " + bin_status);
  } else {
    Serial.println("Firebase Trashbbin Status FAILED: " + firebaseData.errorReason());
  }
}


// Send ESPtrashbin status now to Firebase
void sendFirebaseTrashbinStatusNow(const String& update_status) {
  if (Firebase.setString(firebaseData, "/trashbin_notify/lcd", update_status)) {
    Serial.println("Firebase Trashbin Status: " + update_status);
  } else {
    Serial.println("Firebase Trashbbin Status FAILED: " + firebaseData.errorReason());
  }
}

String TrashbinStatusNow() {
  if (!sensorStates[0] && !sensorStates[1] && !sensorStates[2] && !sensorStates[3]) return "EMPTY";
  if (sensorStates[0] && !sensorStates[1] && !sensorStates[2] && !sensorStates[3]) return "LOW";
  if (sensorStates[0] && sensorStates[1] && !sensorStates[2] && !sensorStates[3]) return "MEDIUM";
  if (sensorStates[0] && sensorStates[1] && sensorStates[2] && !sensorStates[3]) return "HIGH";
  if (sensorStates[0] && sensorStates[1] && sensorStates[2] && sensorStates[3]) return "FULL";
  return "UNKNOWN";
}

// PRINT CURRENT TIME
void printTimeLog() {
  struct tm timeinfo;

  if (!getLocalTime(&timeinfo)) {
    Serial.println("Time not available");
    return;
  }

  Serial.printf("WiFi Connected [%02d:%02d:%02d]\n",
                timeinfo.tm_hour,
                timeinfo.tm_min,
                timeinfo.tm_sec
               );

  char timeString[6];

  // HH:MM military format
  strftime(timeString, 6, "%H:%M", &timeinfo);

  Serial.print("Time: ");
  Serial.println(timeString);
  String binStatus = "Trashbin Connected [" + String(timeString) + "]";
  sendFirebaseTrashbinStatus(binStatus);
}

// WIFI CHECK FUNCTION
void checkWiFi() {

  if (WiFi.status() != WL_CONNECTED) {

    Serial.println("WiFi lost. Reconnecting...");

    WiFi.disconnect();
    WiFi.begin(ssid, password);

    int retry = 0;

    while (WiFi.status() != WL_CONNECTED && retry < 20) {
      delay(500);
      Serial.print(".");
      retry++;
    }

    if (WiFi.status() == WL_CONNECTED) {
      Serial.println("\nReconnected!");
      printTimeLog();
    }
    else {
      Serial.println("\nReconnect failed");
    }

  }
  else {

    printTimeLog();

  }

}

void setup()
{
  Serial.begin(115200);
  Serial.setDebugOutput(true);
  Serial.println();

  WiFi.begin(ssid, password);
  WiFi.setSleep(false);
  Serial.print("WiFi connecting");
  sendFirebaseTrashbinStatusNow("Connecting to " + String(ssid));
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.println("WiFi connected");

  Fconfig.api_key = API_KEY;
  auth.user.email = USER_EMAIL;
  auth.user.password = USER_PASSWORD;
  Fconfig.database_url = DATABASE_URL;
  Fconfig.token_status_callback = tokenStatusCallback;
  Firebase.reconnectNetwork(true);
  firebaseData.setBSSLBufferSize(4096 , 1024 );
  Firebase.begin(&Fconfig, &auth);
  Firebase.reconnectWiFi(true);
  firebaseData.setResponseSize(4096);
  // Check Firebase connection
  if (Firebase.ready())
  {
    Serial.println("Firebase Connected");
    sendFirebaseTrashbinStatusNow("Connected");
  }
  else
  {
    Serial.println("Firebase Disconnected");
  }
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  printTimeLog();

  pinMode(TRIG1, OUTPUT);
  pinMode(ECHO1, INPUT);

  pinMode(TRIG2, OUTPUT);
  pinMode(ECHO2, INPUT);

  pinMode(TRIG3, OUTPUT);
  pinMode(ECHO3, INPUT);

  pinMode(TRIG4, OUTPUT);
  pinMode(ECHO4, INPUT);
}

void loop()
{
// Read all sensors and update states/ Firebase using arrays
  for (int i = 0; i < 4; i++) {
    float dist = readUltrasonic(trigPins[i], echoPins[i]);
    int state = (dist >= limitDistance) ? 1 : 0;
    sensorStates[i] = state;
    
    // Generic Firebase update (replace specific functions later or use dynamic path)
    if (Firebase.setInt(firebaseData, sensorPaths[i], state)) {
      Serial.print("Firebase Sensor");
      Serial.print(i+1);
      Serial.print(": ");
      Serial.println(state);
    } else {
      Serial.print("Firebase Sensor");
      Serial.print(i+1);
      Serial.print(" FAILED: ");
      Serial.println(firebaseData.errorReason());
    }
    
    if (state == 0) {  // Print only if occupied (reduce spam)
      Serial.print("US");
      Serial.print(i+1);
      Serial.print(": ");
      Serial.print(dist);
      Serial.print(" cm   ");
    }
  }
  Serial.println(); // New line after prints
  if (Firebase.getInt(firebaseData, "/trashbin_notify/statusFull")) {
    int status_full = firebaseData.intData();
    Serial.print("Status: ");
    Serial.println(status_full);
    if (status_full != 1) {
      bool allEmpty = (sensorStates[0] && sensorStates[1] && sensorStates[2] && sensorStates[3]);
      sendFirebaseTrashbinFull(allEmpty ? 1 : 0);
    }
  }
  else {
    Serial.println(firebaseData.errorReason());
  }

  if(Firebase.getString(firebaseData, "trashbin_notify/lcd")){
    String lcd = firebaseData.stringData();
    if(lcd == "ok"){
      String Bin_Status = TrashbinStatusNow();
      Serial.println(Bin_Status);
      sendFirebaseTrashbinStatusNow(Bin_Status);
    }
  }

  
  delay(5000); // 5 sec
  if (millis() - wifiCheckTime >= wifiInterval) {
    wifiCheckTime = millis();
    checkWiFi();
  }
}
